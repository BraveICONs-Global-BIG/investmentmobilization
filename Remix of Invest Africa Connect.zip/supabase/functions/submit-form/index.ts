import {
  GATEWAY_URL,
  SPREADSHEET_ID,
  SCHEMAS,
  authHeaders,
  ensureSheet,
  stringifyValue,
} from "../_shared/sheets.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const formType = String(body.form_type ?? "").slice(0, 60);
    if (!formType) {
      return new Response(JSON.stringify({ error: "form_type is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build a flat record from all top-level fields plus everything in `extra`.
    const extra = (body.extra && typeof body.extra === "object") ? body.extra : {};
    const { form_type: _ignoredFormType, extra: _ignoredExtra, ...topLevel } = body;
    const record: Record<string, unknown> = {
      submitted_at: new Date().toISOString(),
      ...topLevel,
      ...extra,
    };

    // Pick schema; fall back to a generic "Other" tab so unknown form types
    // are still captured cleanly.
    const schema = SCHEMAS[formType] ?? {
      tab: "Other",
      label: "Other",
      headers: [
        "submitted_at", "form_type", "full_name", "email",
        "organization", "topic", "message", "extra_json",
      ],
    };
    if (!SCHEMAS[formType]) {
      record.form_type = formType;
      record.extra_json = JSON.stringify(extra);
    }

    await ensureSheet(schema.tab, schema.headers);

    const row = schema.headers.map((h) => stringifyValue(record[h]).slice(0, 8000));

    const range = `${schema.tab}!A:${columnLetter(schema.headers.length)}`;
    const url = `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}/values/${range}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`;
    const resp = await fetch(url, {
      method: "POST",
      headers: { ...authHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify({ values: [row] }),
    });

    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      console.error("Sheets append failed", resp.status, data);
      throw new Error(`Sheets append failed [${resp.status}]`);
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("submit-form error:", msg);
    return new Response(JSON.stringify({ success: false, error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function columnLetter(n: number): string {
  let s = "";
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s || "A";
}