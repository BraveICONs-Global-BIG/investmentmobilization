export const SPREADSHEET_ID = "1kDUFNRhOXP4Z0KokObIoUNfaUOhHf6aNoRVOoxSW8j8";
export const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_sheets/v4";

export type SchemaDef = {
  tab: string;
  label: string;
  headers: string[];
};

// One tab per form_type, with explicit, human-readable headers.
export const SCHEMAS: Record<string, SchemaDef> = {
  contact: {
    tab: "Contact",
    label: "Contact",
    headers: [
      "submitted_at", "full_name", "email", "phone", "organization", "topic", "message",
    ],
  },
  register_fellowship: {
    tab: "Fellowship",
    label: "Fellowship",
    headers: [
      "submitted_at", "full_name", "email", "phone", "country",
      "organization", "role", "participantType", "sectors",
      "years", "responsibilities", "previousRoles",
      "hasPipeline", "pipelineDesc", "projectValue", "stage",
      "objective", "commitment", "referral",
    ],
  },
  register_investor: {
    tab: "Investor",
    label: "Investor",
    headers: [
      "submitted_at", "full_name", "email", "phone", "country",
      "organization", "role", "participantType", "sectors",
      "capitalType", "ticketSize", "geo", "geoCountries",
      "opportunities", "engagement",
    ],
  },
  register_partnership: {
    tab: "Partnership",
    label: "Partnership",
    headers: [
      "submitted_at", "full_name", "email", "phone", "country",
      "organization", "role", "participantType", "sectors",
      "orgType", "partnershipType", "partnerObjective", "budget",
    ],
  },
  summit_attendee: {
    tab: "Summit",
    label: "Summit Attendee",
    headers: [
      "submitted_at", "full_name", "email", "phone", "country",
      "organization", "role", "attendeeType", "sectors",
      "objective", "referral",
    ],
  },
  register_institute: {
    tab: "Institute",
    label: "Institute Interest",
    headers: [
      "submitted_at", "full_name", "email", "phone", "organization", "role",
      "country", "participantType", "onsiteDelivery", "facilityLocation",
      "groupSize", "message",
    ],
  },
  siraf_briefing: {
    tab: "SIRAF Briefing",
    label: "SIRAF Briefing Interest",
    headers: [
      "submitted_at", "full_name", "email", "phone", "organization", "role",
      "country", "participantType", "message", "source",
    ],
  },
  register_opportunities: {
    tab: "Opportunities",
    label: "Opportunities Interest",
    headers: [
      "submitted_at", "full_name", "email", "phone", "organization", "role",
      "country", "participantType", "sectors", "geographies",
      "ticketSize", "capitalType", "timeline", "opportunityFocus", "message",
    ],
  },
};

export function authHeaders() {
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
  const GOOGLE_SHEETS_API_KEY = Deno.env.get("GOOGLE_SHEETS_API_KEY");
  if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");
  if (!GOOGLE_SHEETS_API_KEY) throw new Error("GOOGLE_SHEETS_API_KEY is not configured");
  return {
    Authorization: `Bearer ${LOVABLE_API_KEY}`,
    "X-Connection-Api-Key": GOOGLE_SHEETS_API_KEY,
  } as Record<string, string>;
}

export function stringifyValue(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (Array.isArray(v)) return v.join(", ");
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

/**
 * Make sure a tab exists with the right header row. Idempotent.
 */
export async function ensureSheet(tab: string, headers: string[]) {
  const h = authHeaders();

  // 1. Get spreadsheet metadata to see if tab exists.
  const metaResp = await fetch(
    `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}?fields=sheets.properties`,
    { headers: h },
  );
  const meta = await metaResp.json();
  if (!metaResp.ok) {
    console.error("Sheets metadata failed", metaResp.status, meta);
    throw new Error(`Sheets metadata failed [${metaResp.status}]`);
  }
  const exists = (meta.sheets ?? []).some(
    (s: any) => s.properties?.title === tab,
  );

  if (!exists) {
    const addResp = await fetch(
      `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}:batchUpdate`,
      {
        method: "POST",
        headers: { ...h, "Content-Type": "application/json" },
        body: JSON.stringify({
          requests: [{ addSheet: { properties: { title: tab } } }],
        }),
      },
    );
    if (!addResp.ok) {
      const err = await addResp.json().catch(() => ({}));
      console.error("Add sheet failed", addResp.status, err);
      throw new Error(`Add sheet failed [${addResp.status}]`);
    }
  }

  // 2. Check whether row 1 already has the headers; write them if not.
  const headerRange = `${tab}!1:1`;
  const headResp = await fetch(
    `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}/values/${headerRange}`,
    { headers: h },
  );
  const headData = await headResp.json();
  const currentHeaders: string[] = headData?.values?.[0] ?? [];
  const matches =
    currentHeaders.length === headers.length &&
    headers.every((v, i) => currentHeaders[i] === v);

  if (!matches) {
    const writeResp = await fetch(
      `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}/values/${headerRange}?valueInputOption=RAW`,
      {
        method: "PUT",
        headers: { ...h, "Content-Type": "application/json" },
        body: JSON.stringify({ range: headerRange, values: [headers] }),
      },
    );
    if (!writeResp.ok) {
      const err = await writeResp.json().catch(() => ({}));
      console.error("Write headers failed", writeResp.status, err);
      throw new Error(`Write headers failed [${writeResp.status}]`);
    }
  }
}
