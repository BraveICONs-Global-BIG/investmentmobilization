import {
  GATEWAY_URL,
  SPREADSHEET_ID,
  SCHEMAS,
  authHeaders,
} from "../_shared/sheets.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-admin-password, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const ADMIN_PASSWORD = Deno.env.get("ADMIN_PASSWORD");
    if (!ADMIN_PASSWORD) throw new Error("ADMIN_PASSWORD is not configured");
    const headers = authHeaders();

    let provided = req.headers.get("x-admin-password") ?? "";
    if (!provided) {
      try { provided = (await req.json())?.password ?? ""; } catch { /* ignore */ }
    }
    if (provided !== ADMIN_PASSWORD) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Discover which tabs exist so we don't 400 on missing ones.
    const metaResp = await fetch(
      `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}?fields=sheets.properties`,
      { headers },
    );
    const meta = await metaResp.json();
    if (!metaResp.ok) throw new Error(`Sheets metadata failed [${metaResp.status}]`);
    const existingTabs = new Set(
      (meta.sheets ?? []).map((s: any) => s.properties?.title).filter(Boolean),
    );

    const TOPIC_FALLBACKS = ["topic", "role", "participantType", "partnershipType", "capitalType"];
    const MESSAGE_FALLBACKS = [
      "message", "objective", "opportunities", "partnerObjective",
      "responsibilities", "pipelineDesc",
    ];
    const CORE = new Set([
      "submitted_at", "full_name", "email", "organization", "topic", "message", "form_type",
    ]);

    const all: any[] = [];

    for (const [formType, schema] of Object.entries(SCHEMAS)) {
      if (!existingTabs.has(schema.tab)) continue;
      const range = `${schema.tab}!A:${columnLetter(schema.headers.length)}`;
      const r = await fetch(
        `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}/values/${range}`,
        { headers },
      );
      const d = await r.json();
      if (!r.ok) {
        console.error(`Read ${schema.tab} failed`, r.status, d);
        continue;
      }
      const values: string[][] = d.values ?? [];
      // Skip header row.
      for (const row of values.slice(1)) {
        const obj: Record<string, string> = {};
        schema.headers.forEach((h, i) => { obj[h] = row[i] ?? ""; });

        const topic =
          obj.topic ||
          TOPIC_FALLBACKS.map((k) => obj[k]).find((v) => v) ||
          "";
        const message =
          MESSAGE_FALLBACKS.map((k) => obj[k]).find((v) => v) || "";

        const extra: Record<string, string> = {};
        for (const [k, v] of Object.entries(obj)) {
          if (!CORE.has(k) && v) extra[k] = v;
        }

        all.push({
          submitted_at: obj.submitted_at ?? "",
          form_type: formType,
          full_name: obj.full_name ?? "",
          email: obj.email ?? "",
          organization: obj.organization ?? "",
          topic,
          message,
          extra_json: Object.keys(extra).length ? JSON.stringify(extra) : "{}",
        });
      }
    }

    // Also include the legacy "Submissions" tab if it still exists, so older
    // entries remain visible during the transition.
    if (existingTabs.has("Submissions")) {
      const r = await fetch(
        `${GATEWAY_URL}/spreadsheets/${SPREADSHEET_ID}/values/Submissions!A:H`,
        { headers },
      );
      const d = await r.json();
      if (r.ok) {
        const values: string[][] = d.values ?? [];
        for (const row of values.slice(1)) {
          all.push({
            submitted_at: row[0] ?? "",
            form_type: row[1] ?? "",
            full_name: row[2] ?? "",
            email: row[3] ?? "",
            organization: row[4] ?? "",
            topic: row[5] ?? "",
            message: row[6] ?? "",
            extra_json: row[7] ?? "{}",
          });
        }
      }
    }

    // Newest first.
    all.sort((a, b) => (b.submitted_at ?? "").localeCompare(a.submitted_at ?? ""));

    return new Response(JSON.stringify({ submissions: all }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("list-submissions error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function columnLetter(n: number): string {
  let s = "";
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s || "A";
}