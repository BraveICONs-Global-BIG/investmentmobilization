export type SubmitFormPayload = {
  form_type: string;
  [key: string]: unknown;
};

const APPS_SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbwqFLUpoHyQ-bnRKiSHSmAKslHIj28XyRJCVrjPx4oGFRliXUFz2eIPS9MK8yh6lgx5/exec";

export async function submitForm(payload: SubmitFormPayload): Promise<void> {
  // Use no-cors so the browser sends the request without a preflight.
  // Apps Script web apps accept text/plain bodies and parse JSON server-side.
  await fetch(APPS_SCRIPT_URL, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload),
  });
}
