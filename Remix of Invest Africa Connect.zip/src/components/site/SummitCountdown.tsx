import { useEffect, useState } from "react";

const TARGET = new Date("2027-02-01T09:00:00Z").getTime();

const getParts = (ms: number) => {
  const clamped = Math.max(0, ms);
  const days = Math.floor(clamped / 86_400_000);
  const hours = Math.floor((clamped % 86_400_000) / 3_600_000);
  const minutes = Math.floor((clamped % 3_600_000) / 60_000);
  const seconds = Math.floor((clamped % 60_000) / 1000);
  return { days, hours, minutes, seconds };
};

const pad = (n: number, len = 2) => String(n).padStart(len, "0");

export const SummitCountdown = () => {
  const [now, setNow] = useState<number>(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const { days, hours, minutes, seconds } = getParts(TARGET - now);
  const live = TARGET - now <= 0;

  const cells: { label: string; value: string }[] = [
    { label: "Days", value: pad(days, 3) },
    { label: "Hours", value: pad(hours) },
    { label: "Minutes", value: pad(minutes) },
    { label: "Seconds", value: pad(seconds) },
  ];

  return (
    <div
      role="timer"
      aria-live="polite"
      aria-label="Countdown to the AIMS Summit, February 2027"
      className="mb-12 rounded-2xl border border-white/10 bg-[hsl(var(--navy-light))]/60 backdrop-blur p-6 md:p-8"
    >
      <div className="flex items-center gap-3 mb-5">
        <div className="h-px w-8 bg-gold" />
        <span className="text-gold text-[10px] md:text-xs uppercase tracking-[0.3em] font-semibold">
          {live ? "The Summit is live" : "Countdown to the Summit"}
        </span>
      </div>
      <div className="grid grid-cols-4 gap-3 md:gap-5">
        {cells.map((c) => (
          <div
            key={c.label}
            className="rounded-xl bg-navy/70 border border-white/5 px-3 py-4 md:py-6 text-center"
          >
            <div className="font-serif text-3xl md:text-5xl font-bold text-gold tabular-nums leading-none">
              {c.value}
            </div>
            <div className="mt-2 md:mt-3 text-[10px] md:text-xs uppercase tracking-[0.2em] text-white/60">
              {c.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SummitCountdown;