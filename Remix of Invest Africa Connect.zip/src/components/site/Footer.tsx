import { Link } from "react-router-dom";
import logoImg from "@/assets/imo-logo.png";

type FooterLink = { label: string; href: string; external?: boolean };

const cols: { title: string; links: FooterLink[] }[] = [
  {
    title: "Platform",
    links: [
      { label: "About", href: "/#top" },
      { label: "How it Works", href: "/#how" },
      { label: "Ecosystem", href: "/#ecosystem" },
    ],
  },
  {
    title: "Programs",
    links: [
      { label: "Fellowship", href: "/fellowship" },
      { label: "Convenings", href: "/#summit" },
      { label: "Summit", href: "/#summit" },
    ],
  },
  {
    title: "Engage",
    links: [
      { label: "Partnerships", href: "/#partnerships" },
      { label: "Insights", href: "/#insights" },
      { label: "Media", href: "/#insights" },
    ],
  },
  {
    title: "Connect",
    links: [
      { label: "Contact", href: "/contact" },
      { label: "Press", href: "mailto:press@investmentmobilization.org", external: true },
      { label: "Careers", href: "mailto:careers@investmentmobilization.org", external: true },
    ],
  },
];

const FooterAnchor = ({ link }: { link: FooterLink }) => {
  const className = "text-sm hover:text-gold transition-colors";
  if (link.external || link.href.startsWith("mailto:") || link.href.startsWith("http")) {
    return <a href={link.href} className={className}>{link.label}</a>;
  }
  return <Link to={link.href} className={className}>{link.label}</Link>;
};

export const Footer = () => (
  <footer className="bg-charcoal text-white/70">
    <div className="max-w-[1280px] mx-auto px-6 lg:px-10 py-20">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
        <div className="col-span-2 md:col-span-1">
          <div className="mb-4">
            <Link to="/" className="bg-gold text-navy font-semibold text-sm px-3 py-1.5 rounded-md shadow-gold inline-block hover:opacity-90 transition-opacity">
              investmentmobilization.org
            </Link>
          </div>
          <div className="text-white font-bold text-lg leading-tight">
            <div>Global Opportunities</div>
            <div>Global Capital</div>
            <div>Global Outcomes</div>
          </div>
        </div>
        {cols.slice(0, 3).map((c) => (
          <div key={c.title}>
            <h4 className="font-sans text-white text-sm font-semibold mb-4 tracking-wide uppercase">{c.title}</h4>
            <ul className="space-y-3">
              {c.links.map((l) => (
                <li key={l.label}>
                  <FooterAnchor link={l} />
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mt-10">
        {cols.slice(3).map((c) => (
          <div key={c.title}>
            <h4 className="font-sans text-white text-sm font-semibold mb-4 tracking-wide uppercase">{c.title}</h4>
            <ul className="space-y-3">
              {c.links.map((l) => (
                <li key={l.label}>
                  <FooterAnchor link={l} />
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between gap-4 text-xs">
        <p>© {new Date().getFullYear()} InvestmentMobilization.org. All rights reserved.</p>
        <div className="flex gap-6">
          <Link to="/privacy" className="hover:text-gold">Privacy</Link>
          <Link to="/terms" className="hover:text-gold">Terms</Link>
          <Link to="/contact" className="hover:text-gold">Contact</Link>
        </div>
      </div>
    </div>
  </footer>
);