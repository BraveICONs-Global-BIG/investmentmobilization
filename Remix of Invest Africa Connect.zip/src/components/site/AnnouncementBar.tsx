import { useEffect, useState } from "react";
import { Calendar, X } from "lucide-react";
import { BriefingInterestDialog } from "./BriefingInterestDialog";

const STORAGE_KEY = "siraf-briefing-banner-dismissed-v3";

const MESSAGE = "Call for Delegates · Global Investment Briefing, Africa Edition · June 12, 2026 · Invitation-only · Register your interest";

export const AnnouncementBar = () => {
  const [visible, setVisible] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!localStorage.getItem(STORAGE_KEY)) setVisible(true);
  }, []);

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    setVisible(false);
  };

  if (!visible) return null;

  const Item = () => (
    <span className="inline-flex items-center gap-3 mx-8 text-sm font-medium tracking-wide">
      <Calendar className="h-4 w-4 text-gold shrink-0" aria-hidden />
      <span className="text-gold font-semibold uppercase tracking-[0.2em]">Call for Delegates</span>
      <span className="text-white/90">Global Investment Briefing, Africa Edition · June 12, 2026 · Invitation-only</span>
      <span className="underline underline-offset-4 hover:text-gold font-semibold">Register your interest →</span>
      <span className="text-white/30" aria-hidden>•</span>
    </span>
  );

  return (
    <>
      <div className="fixed top-0 inset-x-0 z-[60] bg-black text-white border-b border-white/10">
        <div className="relative h-11 flex items-center overflow-hidden">
          <button
            onClick={() => setOpen(true)}
            aria-label={MESSAGE}
            className="flex-1 overflow-hidden whitespace-nowrap py-2.5 cursor-pointer"
          >
            <div className="inline-flex items-center animate-marquee">
              {Array.from({ length: 6 }).map((_, i) => (
                <Item key={i} />
              ))}
            </div>
          </button>
          <button
            onClick={dismiss}
            aria-label="Dismiss announcement"
            className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 z-10 text-white/60 hover:text-white transition-colors bg-black/80 backdrop-blur p-1 rounded"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
      <BriefingInterestDialog open={open} onOpenChange={setOpen} source="announcement_bar" />
    </>
  );
};
