import { Button } from "@/components/ui/button";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AnnouncementBar } from "./AnnouncementBar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import { useState } from "react";
import logoImg from "@/assets/imo-logo.png";

const links = [
  { label: "About", href: "/about" },
  { label: "The Fellowship", href: "/fellowship" },
  { label: "The Convenings", href: "#summit" },
  { label: "The Institute", href: "/institute" },
  { label: "Partnerships", href: "/partnerships" },
  { label: "Contact Us", href: "/contact" },
];

export const Nav = () => {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const onHome = pathname === "/";
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleAnchor = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (!href.startsWith("#")) return;
    e.preventDefault();
    const id = href.slice(1);
    setMobileOpen(false);
    if (!onHome) {
      navigate(`/#${id}`);
      return;
    }
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 108;
      window.scrollTo({ top, behavior: "smooth" });
      history.replaceState(null, "", `#${id}`);
    }
  };

  return (
    <>
      <AnnouncementBar />
      <header className="fixed top-11 inset-x-0 z-50 bg-navy shadow-[0_2px_20px_-10px_rgba(0,0,0,0.4)] border-b border-white/10">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-10 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center whitespace-nowrap">
            <span className="bg-gold text-navy font-semibold text-sm px-3 py-1.5 rounded-md shadow-gold">
              investmentmobilization.org
            </span>
          </Link>
          <nav className="hidden lg:flex items-center gap-x-8 xl:gap-x-10 flex-1 justify-center">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href.startsWith("#") ? (onHome ? l.href : `/${l.href}`) : l.href}
                onClick={(e) => handleAnchor(e, l.href)}
                className="text-[11px] uppercase tracking-[0.18em] font-semibold text-white/80 hover:text-gold transition-colors whitespace-nowrap"
              >
                {l.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="gold" size="sm" asChild className="whitespace-nowrap hidden sm:inline-flex">
              <Link to="/register">Access Pathways</Link>
            </Button>
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <button
                  aria-label="Open menu"
                  className="lg:hidden inline-flex items-center justify-center h-10 w-10 rounded text-white/90 hover:text-gold hover:bg-white/5 transition-colors"
                >
                  <Menu className="h-6 w-6" />
                </button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-navy text-white border-l border-white/10 w-[85%] sm:w-[360px]">
                <div className="mt-4 mb-8">
                  <span className="bg-gold text-navy font-semibold text-sm px-3 py-1.5 rounded-md shadow-gold inline-block">
                    investmentmobilization.org
                  </span>
                </div>
                <nav className="flex flex-col gap-1">
                  {links.map((l) => (
                    <a
                      key={l.href}
                      href={l.href.startsWith("#") ? (onHome ? l.href : `/${l.href}`) : l.href}
                      onClick={(e) => handleAnchor(e, l.href)}
                      className="text-sm uppercase tracking-[0.18em] font-semibold text-white/85 hover:text-gold transition-colors py-3 border-b border-white/10"
                    >
                      {l.label}
                    </a>
                  ))}
                </nav>
                <div className="mt-8">
                  <Button variant="gold" size="lg" asChild className="w-full">
                    <Link to="/register" onClick={() => setMobileOpen(false)}>Access Pathways</Link>
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
    </>
  );
};
