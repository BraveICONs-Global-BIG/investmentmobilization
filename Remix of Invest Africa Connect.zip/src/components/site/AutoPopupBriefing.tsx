import { useEffect, useRef, useState } from "react";
import { BriefingInterestDialog } from "./BriefingInterestDialog";

const STORAGE_KEY = "briefing_interest_responded";

export const AutoPopupBriefing = () => {
  const [open, setOpen] = useState(false);
  const respondedRef = useRef(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (localStorage.getItem(STORAGE_KEY) === "true") {
      respondedRef.current = true;
      return;
    }

    const first = window.setTimeout(() => {
      if (respondedRef.current) return;
      setOpen(true);
    }, 7000);

    const interval = window.setInterval(() => {
      if (respondedRef.current || localStorage.getItem(STORAGE_KEY) === "true") {
        respondedRef.current = true;
        return;
      }
      setOpen(true);
    }, 7000);

    const handler = () => {
      respondedRef.current = true;
      try { localStorage.setItem(STORAGE_KEY, "true"); } catch {}
      window.clearTimeout(first);
      window.clearInterval(interval);
      setOpen(false);
    };
    window.addEventListener("briefing-interest-submitted", handler);

    return () => {
      window.clearTimeout(first);
      window.clearInterval(interval);
      window.removeEventListener("briefing-interest-submitted", handler);
    };
  }, []);

  const handleOpenChange = (v: boolean) => {
    setOpen(v);
  };

  return <BriefingInterestDialog open={open} onOpenChange={handleOpenChange} source="auto_popup" />;
};
