import { useEffect, useState } from "react";
import { Calendar, X, Sparkles } from "lucide-react";
import { BriefingInterestDialog } from "./BriefingInterestDialog";

const STORAGE_KEY = "siraf-briefing-floating-dismissed-v1";
const RESPONDED_KEY = "briefing_interest_responded";

export const BriefingFloatingCard = () => {
  const [shown, setShown] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (localStorage.getItem(STORAGE_KEY) || localStorage.getItem(RESPONDED_KEY) === "true") return;
    const t = setTimeout(() => setShown(true), 4000);
    const handler = () => {
      try { localStorage.setItem(STORAGE_KEY, "1"); } catch {}
      setShown(false);
      setOpen(false);
    };
    window.addEventListener("briefing-interest-submitted", handler);
    return () => {
      clearTimeout(t);
      window.removeEventListener("briefing-interest-submitted", handler);
    };
  }, []);

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    setShown(false);
  };

  if (!shown) return null;

  return (
    <>
      <div className="fixed bottom-5 right-5 z-40 w-[320px] max-w-[calc(100vw-2.5rem)] animate-in slide-in-from-bottom-5 fade-in duration-500">
        <div className="relative rounded-xl bg-navy text-white border border-white/10 shadow-2xl overflow-hidden">
          <button
            onClick={dismiss}
            aria-label="Close"
            className="absolute top-2 right-2 z-10 text-white/60 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-gold/10 blur-2xl pointer-events-none" />
          <div className="p-5">
            <div className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-gold font-semibold mb-2">
              <Sparkles className="h-3 w-3" /> Invitation-only
            </div>
            <h3 className="font-serif text-lg leading-snug mb-1">
              Why Capital Isn't Flowing into Africa, and How to Fix It
            </h3>
            <p className="text-xs text-white/70 mb-3">
              Global Investment Briefing · 90-min high-level session
            </p>
            <div className="flex items-center gap-2 text-[11px] text-white/80 mb-4">
              <Calendar className="h-3.5 w-3.5 text-gold" />
              Fri, June 12, 2026 · 4PM WAT · Zoom
            </div>
            <button
              onClick={() => setOpen(true)}
              className="w-full text-center text-xs uppercase tracking-[0.18em] font-semibold bg-gold text-navy py-2.5 rounded hover:brightness-110 transition"
            >
              Register Interest
            </button>
          </div>
        </div>
      </div>
      <BriefingInterestDialog open={open} onOpenChange={setOpen} source="floating_card" />
    </>
  );
};
