import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Calendar, Clock, Video } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { submitForm } from "@/lib/submitForm";

const schema = z.object({
  full_name: z.string().trim().min(2, "Name is required").max(120),
  email: z.string().trim().email("Valid email required").max(255),
  phone: z.string().trim().min(7, "Valid phone number required").max(32),
  organization: z.string().trim().max(160).optional().or(z.literal("")),
  role: z.string().trim().max(120).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  participantType: z.string().max(80).optional().or(z.literal("")),
  message: z.string().trim().max(800).optional().or(z.literal("")),
});


type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  source?: string;
};

export const BriefingInterestDialog = ({ open, onOpenChange, source = "announcement" }: Props) => {
  const [submitting, setSubmitting] = useState(false);
  const [participantType, setParticipantType] = useState("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      full_name: String(fd.get("full_name") || ""),
      email: String(fd.get("email") || ""),
      phone: String(fd.get("phone") || ""),
      organization: String(fd.get("organization") || ""),
      role: String(fd.get("role") || ""),
      country: String(fd.get("country") || ""),
      participantType,
      message: String(fd.get("message") || ""),
    };

    const parsed = schema.safeParse(payload);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }
    setSubmitting(true);
    try {
      await submitForm({ form_type: "siraf_briefing", ...parsed.data, extra: { source } });
      toast.success("Thank you, we'll be in touch with briefing details.");
      (e.target as HTMLFormElement).reset();
      setParticipantType("");
      try { localStorage.setItem("briefing_interest_responded", "true"); } catch {}
      window.dispatchEvent(new CustomEvent("briefing-interest-submitted"));
      onOpenChange(false);

    } catch (err) {
      toast.error("Could not submit. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-lg p-0 gap-0 top-[6vh] sm:top-[50%] translate-y-0 sm:translate-y-[-50%] max-h-[92svh] sm:max-h-[90svh] flex flex-col overflow-hidden"
      >
        <DialogHeader className="text-left p-5 sm:p-6 pb-3 sm:pb-3 shrink-0 border-b bg-background">
          <DialogTitle className="font-serif text-xl sm:text-2xl leading-tight pr-10 mt-2 sm:mt-0">Global Investment<br />Mobilization Briefing,<br />Africa Edition</DialogTitle>
          <DialogDescription className="text-xs sm:text-sm">
            Invitation-only · 90-minute high-level session.
            <span className="block whitespace-nowrap">Register your interest to receive a delegate invitation.</span>
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-5 sm:px-6 pb-5 sm:pb-6">
          <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground border-b py-3 mb-4">
            <span className="inline-flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" />Fri, June 12, 2026</span>
            <span className="inline-flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" />4PM WAT</span>
            <span className="inline-flex items-center gap-1.5"><Video className="h-3.5 w-3.5" />Virtual (Zoom)</span>
          </div>

          <form onSubmit={onSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <Label htmlFor="full_name">Full name *</Label>
              <Input id="full_name" name="full_name" required maxLength={120} />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="email">Email *</Label>
              <Input id="email" name="email" type="email" required maxLength={255} />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="phone">Phone number *</Label>
              <Input id="phone" name="phone" type="tel" required maxLength={32} placeholder="+254 700 000 000" />
            </div>

            <div>
              <Label htmlFor="organization">Organization</Label>
              <Input id="organization" name="organization" maxLength={160} />
            </div>
            <div>
              <Label htmlFor="role">Role / Title</Label>
              <Input id="role" name="role" maxLength={120} />
            </div>
            <div>
              <Label htmlFor="country">Country</Label>
              <Input id="country" name="country" maxLength={80} />
            </div>
            <div>
              <Label>I am a…</Label>
              <Select value={participantType} onValueChange={setParticipantType}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Public Sector Executive">Public Sector Executive</SelectItem>
                  <SelectItem value="Private Sector Executive">Private Sector Executive</SelectItem>
                  <SelectItem value="Investor / Capital Provider">Investor / Capital Provider</SelectItem>
                  <SelectItem value="Development Partner">Development Partner</SelectItem>
                  <SelectItem value="Media">Media</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="message">Anything we should know? (optional)</Label>
              <Textarea id="message" name="message" rows={3} maxLength={800} />
            </div>
            <div className="sm:col-span-2 flex items-center justify-end gap-2 pt-2">
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" variant="gold" disabled={submitting}>
                {submitting ? "Submitting…" : "Register Interest"}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>

  );
};
