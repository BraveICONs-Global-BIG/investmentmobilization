import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/**
 * Handles scroll behavior across route changes and hash links:
 * - Route change with no hash -> scroll to top
 * - Route change (or same route) with hash -> scroll to the target element,
 *   accounting for the fixed header. Special-case "#top" -> top of page.
 */
export const ScrollManager = () => {
  const { pathname, hash, key } = useLocation();

  useEffect(() => {
    if (!hash) {
      window.scrollTo({ top: 0, left: 0, behavior: "auto" });
      return;
    }

    const id = hash.replace("#", "");
    if (id === "top") {
      window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
      return;
    }

    // Wait a tick for the target route to render
    const scrollToTarget = () => {
      const el = document.getElementById(id);
      if (!el) return false;
      const headerOffset = 72; // fixed nav height (h-16) + small buffer
      const top = el.getBoundingClientRect().top + window.scrollY - headerOffset;
      window.scrollTo({ top, left: 0, behavior: "smooth" });
      return true;
    };

    if (!scrollToTarget()) {
      const t = setTimeout(scrollToTarget, 80);
      return () => clearTimeout(t);
    }
  }, [pathname, hash, key]);

  return null;
};

export default ScrollManager;