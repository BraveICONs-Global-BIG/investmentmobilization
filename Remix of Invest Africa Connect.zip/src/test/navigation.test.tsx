import { describe, it, expect, beforeAll } from "vitest";
import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import fs from "node:fs";
import path from "node:path";
import React from "react";

import Index from "@/pages/Index";
import Fellowship from "@/pages/Fellowship";
import Contact from "@/pages/Contact";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";
import Register from "@/pages/Register";

// IntersectionObserver shim (some shadcn components touch it).
beforeAll(() => {
  // @ts-expect-error - jsdom shim
  window.IntersectionObserver = class {
    observe() {}
    unobserve() {}
    disconnect() {}
    takeRecords() { return []; }
    root = null;
    rootMargin = "";
    thresholds = [];
  };
  // scrollTo shim
  window.scrollTo = () => {};
});

// ---------- Static scan helpers ----------

const SRC = path.resolve(__dirname, "..");
const linkRegex = /(?:href|to)\s*=\s*["'`]([^"'`]+)["'`]/g;

const walk = (dir: string, out: string[] = []): string[] => {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (["test", "ui"].includes(entry.name)) continue; // skip tests + shadcn primitives
      walk(full, out);
    } else if (/\.(t|j)sx?$/.test(entry.name)) {
      out.push(full);
    }
  }
  return out;
};

type LinkRef = { href: string; file: string };

const collectLinks = (): LinkRef[] => {
  const refs: LinkRef[] = [];
  for (const file of walk(SRC)) {
    const content = fs.readFileSync(file, "utf8");
    let m: RegExpExecArray | null;
    while ((m = linkRegex.exec(content)) !== null) {
      const href = m[1];
      if (!href) continue;
      if (href.startsWith("/") || href.startsWith("#")) {
        refs.push({ href, file: path.relative(SRC, file) });
      }
    }
  }
  return refs;
};

// Routes registered in App.tsx — keep in sync if new routes are added.
const KNOWN_ROUTES = new Set<string>([
  "/",
  "/register",
  "/fellowship",
  "/contact",
  "/privacy",
  "/terms",
]);

const isKnownRoute = (pathname: string): boolean => {
  if (KNOWN_ROUTES.has(pathname)) return true;
  // Dynamic: /register/:path
  if (/^\/register\/[^/]+$/.test(pathname)) return true;
  return false;
};

// Pages that own the hash anchors referenced from anywhere in the app.
const PAGE_COMPONENTS: Record<string, React.ComponentType> = {
  "/": Index,
  "/fellowship": Fellowship,
  "/contact": Contact,
  "/privacy": Privacy,
  "/terms": Terms,
  "/register": Register,
};

const renderRoute = (route: string) => {
  const Page = PAGE_COMPONENTS[route];
  if (!Page) throw new Error(`No page component registered for ${route}`);
  return render(
    <MemoryRouter initialEntries={[route]}>
      <Page />
    </MemoryRouter>
  );
};

// ---------- Tests ----------

describe("navigation integrity", () => {
  const links = collectLinks();

  it("collects internal links from source", () => {
    expect(links.length).toBeGreaterThan(0);
  });

  it("every internal route target is registered in the router", () => {
    const broken: string[] = [];
    for (const { href, file } of links) {
      if (!href.startsWith("/")) continue;
      const url = new URL(href, "http://x");
      const pathname = url.pathname;
      if (!isKnownRoute(pathname)) {
        broken.push(`${file}: ${href} -> unknown route ${pathname}`);
      }
    }
    expect(broken, broken.join("\n")).toEqual([]);
  });

  it("every registered route renders without crashing", () => {
    for (const route of KNOWN_ROUTES) {
      const Page = PAGE_COMPONENTS[route];
      expect(Page, `Missing page component for ${route}`).toBeTruthy();
      const { unmount } = render(
        <MemoryRouter initialEntries={[route]}>
          {React.createElement(Page)}
        </MemoryRouter>
      );
      unmount();
    }
  });

  it("every hash anchor target exists on the page that owns it", () => {
    // Group hashes by the page they should resolve on.
    // Rules:
    //   "#foo" written inside a page file -> must exist on that same page.
    //   "/path#foo"                       -> must exist on the page for /path.
    //   "#foo" inside a shared component (Nav/Footer) -> must exist on home "/".
    const byPage = new Map<string, Set<string>>();
    const add = (page: string, hash: string) => {
      if (!hash) return;
      if (!byPage.has(page)) byPage.set(page, new Set());
      byPage.get(page)!.add(hash.replace(/^#/, ""));
    };

    for (const { href, file } of links) {
      if (href.startsWith("/")) {
        const url = new URL(href, "http://x");
        if (url.hash) add(url.pathname, url.hash);
      } else if (href.startsWith("#")) {
        // Determine owning page from file location.
        if (file.startsWith("pages/")) {
          const name = path.basename(file).replace(/\.(t|j)sx?$/, "");
          const map: Record<string, string> = {
            Index: "/",
            Fellowship: "/fellowship",
            Contact: "/contact",
            Privacy: "/privacy",
            Terms: "/terms",
            Register: "/register",
          };
          if (map[name]) add(map[name], href);
        } else {
          // Shared component (Nav/Footer/etc.) — anchors target the home page.
          add("/", href);
        }
      }
    }

    // Special case: ScrollManager treats "#top" as scroll-to-top, not an element id.
    for (const set of byPage.values()) set.delete("top");

    const missing: string[] = [];
    for (const [route, hashes] of byPage.entries()) {
      if (!PAGE_COMPONENTS[route]) {
        missing.push(`No page component for ${route} (hashes: ${[...hashes].join(", ")})`);
        continue;
      }
      const { container, unmount } = renderRoute(route);
      for (const id of hashes) {
        if (!container.querySelector(`#${CSS.escape(id)}`)) {
          missing.push(`${route} is missing #${id}`);
        }
      }
      unmount();
    }

    expect(missing, missing.join("\n")).toEqual([]);
  });
});
