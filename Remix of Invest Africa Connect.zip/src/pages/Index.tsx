import { ArrowRight, Building2, Compass, Layers, LineChart, Target, TrendingUp, Users, Globe2, Briefcase, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { SummitCountdown } from "@/components/site/SummitCountdown";
import { BriefingFloatingCard } from "@/components/site/BriefingFloatingCard";
import { AutoPopupBriefing } from "@/components/site/AutoPopupBriefing";

import { Link } from "react-router-dom";
import heroImg from "@/assets/hero-network.jpg";
import fellowshipImg from "@/assets/aims-fellowship.png";
import summitImg from "@/assets/aims-summit.png";
import bgNetwork from "@/assets/bg-network.png";
import partnershipsImg from "@/assets/aims-partnerships.jpg";
import ecosystemImg from "@/assets/aims-ecosystem.jpg";
import mediaSkyline from "@/assets/media-africa-skyline.jpg";
import africaMap from "@/assets/africa-map.jpg";
import mediaBoardroom from "@/assets/media-boardroom.jpg";
import mediaCapital from "@/assets/media-capital-flows.jpg";
import mediaInfra from "@/assets/media-infrastructure.jpg";
import partnerAU from "@/assets/partners/african-union.png";
import partnerUBA from "@/assets/partners/uba.png";
import partnerIFC from "@/assets/partners/ifc.png";
import partnerDFC from "@/assets/partners/dfc.png";
import partnerEBRD from "@/assets/partners/european-bank.png";
import partnerWTC from "@/assets/partners/wtc.png";
import partnerBIG from "@/assets/partners/big.png";

const partnerLogos = [
  { src: partnerAU, alt: "African Union", scale: 1 },
  { src: partnerUBA, alt: "United Bank for Africa", scale: 1.5 },
  { src: partnerIFC, alt: "International Finance Corporation", scale: 1.5 },
  { src: partnerDFC, alt: "U.S. International Development Finance Corporation", scale: 1 },
  { src: partnerEBRD, alt: "European Bank for Reconstruction and Development", scale: 1 },
  { src: partnerWTC, alt: "World Trade Center Abuja", scale: 1 },
  { src: partnerBIG, alt: "BIG Advisory Capital Private", scale: 1 },
];

const heroCarousel = [heroImg, mediaSkyline, mediaCapital, mediaInfra, mediaBoardroom, ecosystemImg];

const Section = ({
  id,
  variant = "light",
  eyebrow,
  title,
  intro,
  children,
}: {
  id?: string;
  variant?: "light" | "dark" | "soft";
  eyebrow?: string;
  title?: string;
  intro?: string;
  children?: React.ReactNode;
}) => {
  const bg =
    variant === "dark" ? "bg-navy text-white" : variant === "soft" ? "bg-gray-light text-navy" : "bg-background text-navy";
  const showNetwork = variant === "light" || variant === "soft";
  return (
    <section id={id} className={`${bg} relative py-12 md:py-16 overflow-hidden`}>
      {showNetwork && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-center bg-cover opacity-[0.06] mix-blend-multiply"
          style={{ backgroundImage: `url(${bgNetwork})` }}
        />
      )}
      {showNetwork && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              variant === "soft"
                ? "linear-gradient(180deg, hsl(var(--gray-light)) 0%, transparent 30%, transparent 70%, hsl(var(--gray-light)) 100%)"
                : "linear-gradient(180deg, hsl(var(--background)) 0%, transparent 30%, transparent 70%, hsl(var(--background)) 100%)",
          }}
        />
      )}
      <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10">
        {(eyebrow || title || intro) && (
          <div className="max-w-3xl mb-8">
            {eyebrow && (
              <div className="flex items-center gap-3 mb-5">
                <div className="h-px w-10 bg-gold" />
                <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">{eyebrow}</span>
              </div>
            )}
            {title && <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.05] mb-6 whitespace-pre-line">{title}</h2>}
            {intro && <p className={`text-lg md:text-xl leading-relaxed ${variant === "dark" ? "text-white/70" : "text-gray-medium"}`}>{intro}</p>}
          </div>
        )}
        {children}
      </div>
    </section>
  );
};

const Hero = () => (
  <section className="relative gradient-hero text-white pt-28 pb-10 md:pt-32 md:pb-12 overflow-hidden">
    <div className="absolute inset-0 opacity-30">
      <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-gold/20 blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[hsl(var(--navy-light))] blur-[140px]" />
    </div>
    <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10 grid lg:grid-cols-2 gap-16 items-center">
      <div>
        <div className="flex items-center gap-3 mb-6">
          <span className="text-white/80 text-xs uppercase tracking-[0.25em] font-semibold">- AFRICA INVESMENT MOBILIZATION SUMMIT</span>
        </div>
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.02] mb-8">
          Structuring Africa's Next Pipeline of <span className="text-gold italic">Bankable Investments</span>
        </h1>
        <div className="text-lg md:text-xl text-white/75 leading-relaxed mb-10 max-w-xl space-y-1">
          <p>Where structured pipelines meet global capital.</p>
          <p className="font-bold text-white">Engage. Participate. Partner</p>
          <p className="pt-4">February 2027 | Addis Ababa</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <Button variant="gold" size="xl" asChild>
            <Link to="/register">
              EXPRESS YOUR INTEREST <ArrowRight />
            </Link>
          </Button>
        </div>
      </div>
      <div className="relative overflow-hidden rounded-2xl border border-gold/20 shadow-elegant">
        <div className="absolute inset-0 bg-gold/10 blur-3xl pointer-events-none" />
        <div className="relative flex w-max animate-marquee-rtl">
          {[...heroCarousel, ...heroCarousel].map((src, i) => (
            <img
              key={i}
              src={src}
              alt="Africa investment imagery"
              className="h-[420px] md:h-[520px] w-auto object-cover flex-shrink-0"
            />
          ))}
        </div>
      </div>
    </div>
    <div className="bg-white w-full px-6 lg:px-10 py-6 mt-8 relative overflow-hidden">
      <span className="block text-left text-navy text-sm md:text-base uppercase tracking-[0.25em] font-semibold mb-4">
        Proposed Institutions
      </span>
      <div className="relative overflow-hidden mt-6">
        <div className="flex w-max items-center gap-x-16 animate-marquee">
          {[...partnerLogos, ...partnerLogos].map((logo, i) => (
            <img
              key={`${logo.alt}-${i}`}
              src={logo.src}
              alt={logo.alt}
              style={{ height: `${logo.scale * 5}rem` }}
              className="w-auto object-contain mix-blend-multiply flex-shrink-0 grayscale"
            />
          ))}
        </div>
      </div>
    </div>
  </section>
);

const Problem = () => (
  <div className="pt-16 md:pt-24">
    <Section id="challenge" variant="light">
      <Accordion type="single" collapsible className="space-y-4 max-w-5xl mx-auto">
        <AccordionItem value="challenge" className="border-0 bg-gray-light rounded-md overflow-hidden">
          <AccordionTrigger className="px-5 md:px-8 py-5 md:py-6 text-navy font-semibold text-lg md:text-2xl text-left hover:no-underline gap-4">
            The Global Challenge
          </AccordionTrigger>
          <AccordionContent className="px-8 pb-8 text-gray-medium leading-relaxed space-y-4 text-lg md:text-xl">
            <p>
              Despite unprecedented global liquidity, the deployment of capital into productive, scalable and developmentally meaningful opportunities remains persistently constrained, particularly across emerging economies.
            </p>
            <p>
              The challenge is not merely capital availability. It is the absence of coordinated systems capable of converting opportunities into investment-ready and transaction-capable outcomes.
            </p>
            <p>
              To move from potential to prosperity, ecosystems must become capable of sustainably absorbing, structuring, aligning, and deploying capital at scale. Investment mobilization must therefore be treated as whole-of-society infrastructure.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="what-is" className="border-0 bg-gray-light rounded-md overflow-hidden">
          <AccordionTrigger className="px-5 md:px-8 py-5 md:py-6 text-navy font-semibold text-lg md:text-2xl text-left hover:no-underline gap-4">
            What is Investment Mobilization
          </AccordionTrigger>
          <AccordionContent className="px-8 pb-8 text-gray-medium leading-relaxed space-y-4 text-lg md:text-xl">
            <p>
              Investment Mobilization is the governance-driven process of converting opportunities into investment-ready, capital-aligned, and transaction-capable outcomes through structured preparation, coordination, readiness assessment, and institutional stewardship.
            </p>
            <p>It is the bridge between opportunity and outcomes.</p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="imo" className="border-0 bg-gray-light rounded-md overflow-hidden">
          <AccordionTrigger className="px-5 md:px-8 py-5 md:py-6 text-navy font-semibold text-lg md:text-2xl text-left hover:no-underline gap-4">
            InvestmentMobilization.Org
          </AccordionTrigger>
          <AccordionContent className="px-8 pb-8 text-gray-medium leading-relaxed space-y-4 text-lg md:text-xl">
            <p>
              A BIG initiative, InvestmentMobilization.Org is catalyzing a global, neutral platform and ecosystem for the advancement of investment mobilization principles, practices, standards, and institutional capabilities.
            </p>
            <p>
              We posit that the global capital deployment gap is not primarily a function of capital scarcity, deal origination, or risk pricing, but of missing mobilization infrastructure. Across markets, investment opportunities frequently fail upstream due to:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>weak readiness articulation,</li>
              <li>fragmented preparation standards,</li>
              <li>unclear institutional accountability,</li>
              <li>insufficient governance assurance,</li>
              <li>and inadequate coordination mechanisms.</li>
            </ul>
            <p>
              Through the InvestmentMobilization.Org briefings, fellowship, institute, convenings, research, strategic partnerships and global exchange, we advance the systems, stewardship, and institutional architectures required to convert opportunity into sustainable prosperity outcomes.
            </p>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <div className="flex justify-center mt-12">
        <Link
          to="/register"
          className="block bg-navy text-white rounded-2xl px-16 py-6 shadow-elegant hover:bg-navy/90 transition-colors text-center"
        >
          <div className="text-3xl md:text-4xl font-extrabold tracking-wide">EXPLORE PATHWAYS</div>
          <div className="mt-2 text-sm md:text-base font-semibold">Raise Capital. Invest Globally. Get Certified</div>
        </Link>
      </div>
    </Section>
  </div>
);


const Platform = () => (
  <section id="about" className="bg-navy text-white relative py-24 md:py-32 overflow-hidden">
    <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10">
      <div className="mb-14">
        <div className="flex items-center gap-3 mb-5">
          <div className="h-px w-10 bg-gold" />
          <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">About</span>
        </div>
        <h2 className="font-serif italic text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.05]">
          A <span className="underline decoration-2 underline-offset-4">Structured</span><br />
          Investment Mobilization Ecosystem
        </h2>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {[
          { title: "Global Briefings", desc: "Insights & Alignment", icon: Compass },
          { title: "The Fellowship", desc: "Readiness & Structuring", icon: Layers },
          { title: "Convenings", desc: "Capital & Deal Flow", icon: TrendingUp },
          { title: "The Exchange", desc: "Bankable Pipeline", icon: Globe2 },
          { title: "The Institute", desc: "Learning & Certification", icon: Users },
          { title: "Partnerships", desc: "Enabling Outcomes", icon: Briefcase },
        ].map((s) => (
          <div key={s.title} className="relative group">
            <div className="absolute -inset-px bg-gradient-to-br from-gold/30 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative bg-[hsl(var(--navy-light))] border border-white/5 p-8 rounded-2xl h-full">
              <div className="flex justify-end mb-6">
                <s.icon className="h-7 w-7 text-gold" />
              </div>
              <h3 className="font-serif text-2xl font-bold mb-2">{s.title}</h3>
              <p className="text-white/60">{s.desc}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-center">
        <Link
          to="/register"
          className="block bg-white text-navy rounded-2xl px-16 py-6 shadow-elegant hover:bg-white/90 transition-colors text-center"
        >
          <div className="text-3xl md:text-4xl font-extrabold tracking-wide text-black">EXPLORE PATHWAYS</div>
          <div className="mt-2 text-sm md:text-base font-semibold text-black">Raise Capital. Invest Globally. Get Certified</div>
        </Link>
      </div>
    </div>
  </section>
);

const HowItWorks = () => {
  const steps = [
    { n: "01", title: "Insight", icon: Compass, points: ["Understanding what makes opportunities investable", "Aligning with global capital expectations"] },
    { n: "02", title: "Readiness", icon: Target, points: ["Identifying high-potential opportunities", "Establishing strategic direction"] },
    { n: "03", title: "Structuring", icon: Layers, points: ["Developing bankable, investor-aligned projects", "Defining risk, returns, delivery models"] },
    { n: "04", title: "Capital", icon: TrendingUp, points: ["Engaging investors", "Facilitating partnerships", "Driving deal flow"] },
  ];
  return (
    <Section id="how" eyebrow="How It Works" title="From Insight to Capital Deployment" intro="A systematic pathway to investment, not isolated interventions.">
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((s) => (
          <div key={s.n} className="bg-white border border-border rounded-2xl p-8 hover:shadow-elegant transition-shadow flex flex-col">
            <div className="font-serif text-5xl text-gold mb-4">{s.n}</div>
            <h3 className="text-2xl font-bold text-navy mb-5">{s.title}</h3>
            <ul className="space-y-3">
              {s.points.map((p) => (
                <li
                  key={p}
                  className="text-sm text-gray-medium leading-relaxed grid grid-cols-[auto_1fr] gap-x-2 text-left"
                >
                  <span aria-hidden="true" className="text-gold select-none">, </span>
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Section>
  );
};

const Fellowship = () => (
  <Section id="fellowship" variant="soft" eyebrow="THE Fellowship" title="The Investment Readiness Engine"
    intro="An intensive executive bootcamp where opportunities\nare structured into bankable projects and investment-ready pipelines,\nand project promoters aligned with global capital expectations."
  >
    <div className="grid lg:grid-cols-2 gap-10 items-stretch mb-12">
      <div className="relative">
        <div className="absolute -inset-2 bg-gold/10 rounded-2xl blur-2xl" />
        <img
          src={fellowshipImg}
          alt="Executive boardroom strategy session reviewing global market dashboards"
          loading="lazy"
          className="relative w-full h-full object-cover rounded-2xl shadow-elegant border border-navy/10"
        />
      </div>
      <div className="grid gap-6">
      <div className="bg-white p-10 rounded-2xl border border-border">
        <h3 className="text-xl font-bold text-navy mb-6 flex items-center gap-3">
          <Users className="h-5 w-5 text-gold" /> Who It's For
        </h3>
        <ul className="space-y-4">
          {["Government leaders and agencies", "Private sector developers and operators", "Enterprises seeking capital"].map((s) => (
            <li key={s} className="flex items-start gap-3 text-gray-medium">
              <ArrowRight className="h-4 w-4 text-gold mt-1 flex-shrink-0" />
              <span>{s}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="bg-navy text-white p-10 rounded-2xl shadow-elegant">
        <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
          <LineChart className="h-5 w-5 text-gold" /> What Participants Gain
        </h3>
        <ul className="space-y-4">
          {["Structured investment opportunities", "Strategic clarity on deal development", "Positioning for capital engagement"].map((s) => (
            <li key={s} className="flex items-start gap-3 text-white/80">
              <ArrowRight className="h-4 w-4 text-gold mt-1 flex-shrink-0" />
              <span>{s}</span>
            </li>
          ))}
        </ul>
      </div>
      </div>
    </div>
    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
      <p className="text-xl font-serif italic text-navy">From ideas to investment-ready pipelines.</p>
      <Button variant="navyOutline" size="lg" asChild>
        <Link to="/fellowship#apply">APPLY TO THE FELLOWSHIP <ArrowRight /></Link>
      </Button>
    </div>
  </Section>
);

const Summit = () => (
  <Section id="summit" variant="dark" eyebrow="AIMS Summit" title="Where Structured Pipelines Meet Global Capital">
    <SummitCountdown />
    <div className="relative mb-12 rounded-2xl overflow-hidden border border-white/10 shadow-elegant">
      <img
        src={summitImg}
        alt="Global investment summit reception with delegates networking"
        loading="lazy"
        className="w-full h-[280px] md:h-[380px] object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/85 to-navy/30" />
      <div className="absolute inset-0 bg-gradient-to-r from-navy/90 via-navy/40 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
        <p className="text-gold text-xs uppercase tracking-[0.25em] font-semibold mb-3 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">Convening</p>
        <p className="text-white text-2xl md:text-3xl font-serif italic max-w-xl drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)]">A curated gathering of capital, governments, and operators.</p>
      </div>
    </div>
    <div className="flex flex-wrap gap-8 mb-12">
      <div className="flex items-center gap-3 text-white/90">
        <MapPin className="h-5 w-5 text-gold" /> <span className="text-lg">Addis Ababa</span>
      </div>
      <div className="flex items-center gap-3 text-white/90">
        <Calendar className="h-5 w-5 text-gold" /> <span className="text-lg">February 2027</span>
      </div>
    </div>
    <div className="grid lg:grid-cols-2 gap-12">
      <div>
        <h3 className="text-2xl font-bold mb-6">What Happens at AIMS</h3>
        <div className="space-y-4">
          {[
            { t: "Pipeline Showcase", d: "Investment-ready opportunities presented to capital" },
            { t: "Investor Engagement", d: "Direct dialogue between developers and capital providers" },
            { t: "Deal Origination", d: "Strategic partnerships formed and deals initiated" },
          ].map((s) => (
            <div key={s.t} className="flex gap-4 p-5 bg-[hsl(var(--navy-light))] rounded-xl">
              <div className="h-2 w-2 rounded-full bg-gold mt-2 flex-shrink-0" />
              <div>
                <p className="font-semibold">{s.t}</p>
                <p className="text-white/60 text-sm">{s.d}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h3 className="text-2xl font-bold mb-6">Who Attends</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { t: "Governments", icon: Building2 },
            { t: "Private Sector", icon: Briefcase },
            { t: "Institutional Investors", icon: TrendingUp },
            { t: "DFIs", icon: Globe2 },
          ].map((s) => (
            <div key={s.t} className="border border-white/10 p-6 rounded-xl hover:border-gold/40 transition-colors">
              <s.icon className="h-6 w-6 text-gold mb-3" />
              <p className="font-semibold">{s.t}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
    <div className="mt-12 flex flex-col md:flex-row md:items-center md:justify-between gap-6 pt-12 border-t border-white/10">
      <p className="text-xl font-serif italic text-gold">A deal-oriented platform, not a conference.</p>
      <Button variant="gold" size="lg" asChild>
        <Link to="/summit">Join the Summit <ArrowRight /></Link>
      </Button>
    </div>
  </Section>
);

const Ecosystem = () => (
  <Section id="ecosystem" eyebrow="Ecosystem" title="A Curated Network of Decision-Makers" intro="AIMS brings together the actors that move capital across Africa.">
    <div className="grid lg:grid-cols-5 gap-10 items-center mb-10">
      <div className="lg:col-span-2 relative">
        <div className="absolute -inset-2 bg-gold/10 rounded-2xl blur-2xl" />
        <img
          src={ecosystemImg}
          alt="Diverse investment leaders convening around a roundtable"
          loading="lazy"
          className="relative w-full rounded-2xl shadow-elegant border border-navy/10 object-cover"
        />
      </div>
      <div className="lg:col-span-3 grid sm:grid-cols-1 gap-4">
      {[
        { t: "Public Sector", d: "Governments shaping policy, pipelines and infrastructure", icon: Building2 },
        { t: "Private Sector", d: "Developers, operators, and enterprises driving execution", icon: Briefcase },
        { t: "Capital", d: "SWFs, DFIs, MDBs, PEFs, VCs, Family offices, and other global structured finance actors.", icon: TrendingUp },
      ].map((s) => (
        <div key={s.t} className="bg-gray-light p-6 rounded-2xl border-l-4 border-gold flex gap-5 items-start">
          <s.icon className="h-8 w-8 text-navy flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-xl font-bold text-navy mb-1">{s.t}</h3>
            <p className="text-gray-medium leading-relaxed text-sm">{s.d}</p>
          </div>
        </div>
      ))}
      </div>
    </div>
    <p className="mt-10 text-center font-serif italic text-lg text-navy">
      Curated participation. Strategic engagement. Real outcomes.
    </p>
  </Section>
);

const Partnerships = () => (
  <Section id="partnerships" variant="soft" eyebrow="Partnerships" title={"Position Within Global \nInvestment Pipeline"}
    intro="IMX partners with organizations seeking early access to investment opportunities, engagement with decision-makers, and strategic positioning in emerging deals."
  >
    <div className="grid lg:grid-cols-2 gap-10 items-center mb-12">
      <div className="relative order-2 lg:order-1">
        <div className="absolute -inset-2 bg-gold/10 rounded-2xl blur-2xl" />
        <img
          src={partnershipsImg}
          alt="Executives sealing a strategic partnership"
          loading="lazy"
          className="relative w-full rounded-2xl shadow-elegant border border-navy/10 object-cover aspect-[4/3]"
        />
      </div>
      <div className="grid gap-4 order-1 lg:order-2">
      {["Strategic Partners", "Program Partners", "Capital Partners"].map((p, i) => (
        <div key={p} className="bg-white p-8 rounded-2xl shadow-elegant flex items-center gap-6">
          <span className="font-serif text-gold text-2xl">0{i + 1}</span>
          <h3 className="text-xl font-bold text-navy">{p}</h3>
        </div>
      ))}
      </div>
    </div>
    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
      <p className="text-xl font-serif italic text-navy">This is not sponsorship, it is participation in an investment ecosystem.</p>
      <Button variant="navyOutline" size="lg" asChild>
        <Link to="/contact?topic=partnerships">Become a Partner <ArrowRight /></Link>
      </Button>
    </div>
  </Section>
);

const Insights = () => {
  const mediaItems = [
    { src: mediaSkyline, alt: "African city skyline representing economic growth and investment opportunity", label: "Economic Growth" },
    { src: mediaBoardroom, alt: "Executive leaders reviewing investment strategy in boardroom", label: "Strategic Engagement" },
    { src: mediaCapital, alt: "Abstract visualization of global capital flows into Africa", label: "Capital Networks" },
    { src: mediaInfra, alt: "Major infrastructure development project in Africa", label: "Infrastructure" },
  ];
  return (
    <Section id="insights" eyebrow="Media" title="Investment in Focus"
      intro="Visual perspectives on Africa's investment landscape, from boardrooms to infrastructure, capital flows to city skylines."
    >
      <div className="grid md:grid-cols-2 gap-6 mb-16">
        {mediaItems.map((item) => (
          <div key={item.label} className="group relative rounded-2xl overflow-hidden shadow-elegant border border-navy/10">
            <img
              src={item.src}
              alt={item.alt}
              loading="lazy"
              width={1344}
              height={1024}
              className="w-full h-[260px] md:h-[320px] object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <span className="text-gold text-xs uppercase tracking-[0.2em] font-semibold">{item.label}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          "Investment readiness",
          "Pipeline structuring",
          "PPP frameworks",
          "Capital alignment strategies",
        ].map((item) => (
          <div key={item} className="group bg-gray-light hover:bg-navy hover:text-white transition-colors p-8 rounded-2xl cursor-pointer flex flex-col">
            <div className="h-px w-8 bg-gold mb-6" />
            <h3 className="text-lg font-bold leading-tight mb-3">{item}</h3>
            <ArrowRight className="mt-6 h-5 w-5 text-gold opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mt-16">
        <p className="text-xl font-serif italic text-navy">Shifting the narrative from funding to structuring.</p>
        <Button variant="navyOutline" size="lg" asChild>
          <Link to="/contact?topic=general">Explore Insights <ArrowRight /></Link>
        </Button>
      </div>
    </Section>
  );
};

const FAQ = () => {
  const items = [
    {
      q: "What is AIMS and how is it different from a conference?",
      a: "AIMS is a multi-stage investment platform, not a one-off event. It connects governments, enterprises, and capital through strategic briefings, THE Fellowship, and a curated Summit designed to move opportunities from concept to capital deployment.",
    },
    {
      q: "Who should apply to THE Fellowship?",
      a: "Government leaders and agencies, private-sector developers and operators, and enterprises preparing to engage institutional capital. It is built for decision-makers shaping or structuring real investment opportunities.",
    },
    {
      q: "When and where is the AIMS Summit?",
      a: "The AIMS Summit takes place in Addis Ababa in February 2027. It is a deal-oriented convening of governments, private-sector operators, DFIs, and institutional investors.",
    },
    {
      q: "How do partnerships with AIMS work?",
      a: "Partnerships are participatory, not sponsorship-based. Strategic, Program, and Capital partners gain early access to pipelines, direct engagement with decision-makers, and positioning in emerging deals.",
    },
    {
      q: "Does AIMS provide funding directly?",
      a: "No. AIMS structures pipelines, builds investment readiness, and connects opportunities with capital providers. Funding decisions remain with investors, our role is to make opportunities credible, aligned, and investable.",
    },
    {
      q: "How can I get in touch or stay informed?",
      a: "Use the Contact page for inquiries, partnership conversations, or press. You can also register your interest through the Access Investment Pathways CTA to be included in future briefings.",
    },
  ];

  return (
    <Section
      id="faq"
      variant="soft"
      eyebrow="FAQ"
      title="Frequently Asked Questions"
      intro="Answers to the questions we hear most often from governments, operators, and capital providers."
    >
      <div className="max-w-3xl">
        <Accordion type="single" collapsible className="space-y-4">
          {items.map((item, i) => (
            <AccordionItem
              key={item.q}
              value={`item-${i}`}
              className="bg-white border border-border rounded-2xl px-6 data-[state=open]:shadow-elegant transition-shadow"
            >
              <AccordionTrigger className="text-left text-navy font-semibold text-base md:text-lg hover:no-underline py-5">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="text-gray-medium leading-relaxed text-base pb-5">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </Section>
  );
};

const FinalCTA = () => (
  <section id="cta" className="bg-navy text-white py-16 md:py-20 relative overflow-hidden">
    <div
      aria-hidden="true"
      className="absolute inset-0 bg-center bg-cover opacity-20"
      style={{ backgroundImage: `url(${africaMap})` }}
    />
    <div className="absolute inset-0 bg-gradient-to-b from-navy/80 via-navy/70 to-navy/90" />
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-gold/10 blur-[150px]" />
    <div className="relative max-w-4xl mx-auto px-6 text-center">
      <div className="flex items-center justify-center gap-3 mb-6">
        <div className="h-px w-10 bg-gold" />
        <span className="text-white text-xs uppercase tracking-[0.25em] font-semibold">AIMS 2027</span>
        <div className="h-px w-10 bg-gold" />
      </div>
      <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] mb-8 whitespace-pre-line">
        Enter Africa's Structured&nbsp;{"\n"}
        <span className="text-gold italic">Investment Pipeline</span>
      </h2>
      <p className="text-xl text-white/75 leading-relaxed mb-12 max-w-2xl mx-auto">
        Position yourself where opportunities are structured, aligned, and connected to capital.
      </p>
      <Button size="xl" asChild className="bg-white text-navy hover:bg-white/90">
        <Link to="/register">
          EXPRESS YOUR INTEREST <ArrowRight />
        </Link>
      </Button>
      <p className="mt-8 text-sm text-white/50 italic">Build pipelines. Engage capital. Execute deals.</p>
    </div>
  </section>
);

const Index = () => (
  <main className="min-h-screen bg-background">
    <Nav />
    <Problem />
    <FinalCTA />
    <Hero />
    
    
    
    <Ecosystem />
    <Summit />
    
    
    <Footer />
    <BriefingFloatingCard />
    <AutoPopupBriefing />

  </main>
);

export default Index;
