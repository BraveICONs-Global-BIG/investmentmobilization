import { Compass, Layers, TrendingUp, Globe2, Users, Briefcase } from "lucide-react";
import { Link } from "react-router-dom";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import bgNetwork from "@/assets/bg-network.png";

const items = [
  { title: "Global Briefings", desc: "Insights & Alignment", icon: Compass },
  { title: "The Fellowship", desc: "Readiness & Structuring", icon: Layers },
  { title: "Convenings", desc: "Capital & Deal Flow", icon: TrendingUp },
  { title: "The Exchange", desc: "Bankable Pipeline", icon: Globe2 },
  { title: "The Institute", desc: "Learning & Certification", icon: Users },
  { title: "Partnerships", desc: "Enabling Outcomes", icon: Briefcase },
];

const About = () => (
  <main className="min-h-screen bg-background">
    <Nav />
    <section id="overview" className="bg-gray-light relative pt-44 pb-16 md:pt-52 md:pb-20 overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-center bg-cover opacity-[0.06] mix-blend-multiply"
        style={{ backgroundImage: `url(${bgNetwork})` }}
      />
      <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10">
        <Accordion type="single" collapsible className="space-y-4 max-w-5xl mx-auto">
          <AccordionItem value="challenge" className="border-0 bg-white rounded-md overflow-hidden">
            <AccordionTrigger className="px-5 md:px-8 py-5 md:py-6 text-navy font-semibold text-lg md:text-2xl text-left hover:no-underline gap-4">
              The Global Challenge
            </AccordionTrigger>
            <AccordionContent className="px-8 pb-8 text-gray-medium leading-relaxed space-y-4 text-lg md:text-xl">
              <p>
                Despite unprecedented global liquidity, the deployment of capital into productive, scalable and developmentally meaningful opportunities remains persistently constrained, particularly across emerging economies.
              </p>
              <p>
                The challenge is not merely capital availability. It is the absence of coordinated systems capable of converting opportunities into investment-ready and transaction-capable outcomes.
              </p>
              <p>
                To move from potential to prosperity, ecosystems must become capable of sustainably absorbing, structuring, aligning, and deploying capital at scale. Investment mobilization must therefore be treated as whole-of-society infrastructure.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="what-is" className="border-0 bg-white rounded-md overflow-hidden">
            <AccordionTrigger className="px-5 md:px-8 py-5 md:py-6 text-navy font-semibold text-lg md:text-2xl text-left hover:no-underline gap-4">
              What is Investment Mobilization
            </AccordionTrigger>
            <AccordionContent className="px-8 pb-8 text-gray-medium leading-relaxed space-y-4 text-lg md:text-xl">
              <p>
                Investment Mobilization is the governance-driven process of converting opportunities into investment-ready, capital-aligned, and transaction-capable outcomes through structured preparation, coordination, readiness assessment, and institutional stewardship.
              </p>
              <p>It is the bridge between opportunity and outcomes.</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="imo" className="border-0 bg-white rounded-md overflow-hidden">
            <AccordionTrigger className="px-5 md:px-8 py-5 md:py-6 text-navy font-semibold text-lg md:text-2xl text-left hover:no-underline gap-4">
              InvestmentMobilization.Org
            </AccordionTrigger>
            <AccordionContent className="px-8 pb-8 text-gray-medium leading-relaxed space-y-4 text-lg md:text-xl">
              <p>
                A BIG initiative, InvestmentMobilization.Org is catalyzing a global, neutral platform and ecosystem for the advancement of investment mobilization principles, practices, standards, and institutional capabilities.
              </p>
              <p>
                We posit that the global capital deployment gap is not primarily a function of capital scarcity, deal origination, or risk pricing, but of missing mobilization infrastructure. Across markets, investment opportunities frequently fail upstream due to:
              </p>
              <ul className="list-disc pl-6 space-y-1">
                <li>weak readiness articulation,</li>
                <li>fragmented preparation standards,</li>
                <li>unclear institutional accountability,</li>
                <li>insufficient governance assurance,</li>
                <li>and inadequate coordination mechanisms.</li>
              </ul>
              <p>
                Through the InvestmentMobilization.Org briefings, fellowship, institute, convenings, research, strategic partnerships and global exchange, we advance the systems, stewardship, and institutional architectures required to convert opportunity into sustainable prosperity outcomes.
              </p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="flex justify-center mt-12">
          <Link
            to="/register"
            className="block bg-navy text-white rounded-2xl px-16 py-6 shadow-elegant hover:bg-navy/90 transition-colors text-center"
          >
            <div className="text-3xl md:text-4xl font-extrabold tracking-wide">EXPLORE PATHWAYS</div>
            <div className="mt-2 text-sm md:text-base font-semibold">Raise Capital. Invest Globally. Get Certified</div>
          </Link>
        </div>
      </div>
    </section>
    <section id="about" className="bg-navy text-white relative py-24 md:py-32 overflow-hidden">
      <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10 bg-gold" />
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">About</span>
          </div>
          <h1 className="font-serif italic text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.05]">
            A <span className="underline decoration-2 underline-offset-4">Structured</span><br />
            Investment Mobilization Ecosystem
          </h1>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {items.map((s) => (
            <div key={s.title} className="relative group">
              <div className="absolute -inset-px bg-gradient-to-br from-gold/30 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative bg-[hsl(var(--navy-light))] border border-white/5 p-8 rounded-2xl h-full">
                <div className="flex justify-end mb-6">
                  <s.icon className="h-7 w-7 text-gold" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-2">{s.title}</h3>
                <p className="text-white/60">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-center">
          <Link
            to="/register"
            className="block bg-white text-navy rounded-2xl px-16 py-6 shadow-elegant hover:bg-white/90 transition-colors text-center"
          >
            <div className="text-3xl md:text-4xl font-extrabold tracking-wide text-black">EXPLORE PATHWAYS</div>
            <div className="mt-2 text-sm md:text-base font-semibold text-black">Raise Capital. Invest Globally. Get Certified</div>
          </Link>
        </div>
      </div>
    </section>
    <Footer />
  </main>
);

export default About;
