import { useEffect, useMemo, useState } from "react";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, Search, RefreshCw, LogOut, Eye, Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type Submission = {
  submitted_at: string;
  form_type: string;
  full_name: string;
  email: string;
  organization: string;
  topic: string;
  message: string;
  extra_json: string;
};

const STORAGE_KEY = "aims_admin_pwd";

const Admin = () => {
  const [password, setPassword] = useState<string>(() => sessionStorage.getItem(STORAGE_KEY) ?? "");
  const [authed, setAuthed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<Submission[]>([]);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [selected, setSelected] = useState<Submission | null>(null);

  const fetchData = async (pwd: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("list-submissions", {
        body: { password: pwd },
      });
      if (error || (data as any)?.error) {
        const msg = (data as any)?.error ?? error?.message ?? "Failed";
        if (String(msg).toLowerCase().includes("unauth")) {
          sessionStorage.removeItem(STORAGE_KEY);
          setAuthed(false);
          toast.error("Incorrect password");
        } else {
          toast.error("Could not load submissions");
        }
        return;
      }
      setRows((data as any).submissions ?? []);
      setAuthed(true);
      sessionStorage.setItem(STORAGE_KEY, pwd);
    } catch {
      toast.error("Could not load submissions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const saved = sessionStorage.getItem(STORAGE_KEY);
    if (saved) fetchData(saved);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      if (filter !== "all" && r.form_type !== filter) return false;
      if (!q) return true;
      return [r.full_name, r.email, r.organization, r.topic, r.message, r.form_type]
        .join(" ").toLowerCase().includes(q);
    });
  }, [rows, query, filter]);

  const formTypes = useMemo(
    () => Array.from(new Set(rows.map((r) => r.form_type))).filter(Boolean),
    [rows],
  );

  const exportCsv = () => {
    if (filtered.length === 0) {
      toast.error("Nothing to export");
      return;
    }
    const headers = [
      "submitted_at","form_type","full_name","email","organization","topic","message","extra_json",
    ];
    const escape = (v: string) => {
      const s = (v ?? "").toString();
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [headers.join(",")];
    for (const r of filtered) {
      lines.push(headers.map((h) => escape((r as any)[h])).join(","));
    }
    const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `aims-submissions-${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  if (!authed) {
    return (
      <div className="min-h-screen bg-background">
        <Nav />
        <section className="pt-32 pb-20">
          <div className="max-w-md mx-auto px-6">
            <div className="bg-white border border-border rounded-xl p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-6">
                <div className="h-10 w-10 rounded-md bg-navy/5 flex items-center justify-center">
                  <Lock className="h-5 w-5 text-navy" />
                </div>
                <div>
                  <h1 className="font-serif text-2xl font-bold text-navy">Admin Access</h1>
                  <p className="text-sm text-muted-foreground">Enter the admin password to continue</p>
                </div>
              </div>
              <form
                onSubmit={(e) => { e.preventDefault(); fetchData(password); }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="pwd">Password</Label>
                  <Input
                    id="pwd"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoFocus
                    required
                  />
                </div>
                <Button type="submit" variant="gold" className="w-full" disabled={loading}>
                  {loading ? "Verifying..." : "Sign in"}
                </Button>
              </form>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <section className="pt-32 pb-20">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="h-px w-10 bg-gold" />
                <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Admin</span>
              </div>
              <h1 className="font-serif text-3xl md:text-4xl font-bold text-navy">Submissions</h1>
              <p className="text-muted-foreground mt-1">{filtered.length} of {rows.length} entries</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={exportCsv} disabled={loading}>
                <Download className="h-4 w-4 mr-1" /> Export CSV
              </Button>
              <Button variant="outline" onClick={() => fetchData(sessionStorage.getItem(STORAGE_KEY) ?? "")} disabled={loading}>
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
              </Button>
              <Button variant="ghost" onClick={() => { sessionStorage.removeItem(STORAGE_KEY); setAuthed(false); setPassword(""); setRows([]); }}>
                <LogOut className="h-4 w-4 mr-1" /> Sign out
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mb-6">
            <div className="relative flex-1 min-w-[260px]">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search name, email, organization, message..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button size="sm" variant={filter === "all" ? "default" : "outline"} onClick={() => setFilter("all")}>All</Button>
              {formTypes.map((t) => (
                <Button key={t} size="sm" variant={filter === t ? "default" : "outline"} onClick={() => setFilter(t)}>
                  {t}
                </Button>
              ))}
            </div>
          </div>

          <div className="bg-white border border-border rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-navy/5 text-navy">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold">Date</th>
                    <th className="text-left px-4 py-3 font-semibold">Type</th>
                    <th className="text-left px-4 py-3 font-semibold">Name</th>
                    <th className="text-left px-4 py-3 font-semibold">Email</th>
                    <th className="text-left px-4 py-3 font-semibold">Organization</th>
                    <th className="text-left px-4 py-3 font-semibold">Topic</th>
                    <th className="text-left px-4 py-3 font-semibold">Message</th>
                    <th className="text-left px-4 py-3 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr><td colSpan={8} className="px-4 py-10 text-center text-muted-foreground">
                      {loading ? "Loading..." : "No submissions found"}
                    </td></tr>
                  )}
                  {filtered.map((r, i) => (
                    <tr key={i} className="border-t border-border align-top hover:bg-muted/30">
                      <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                        {r.submitted_at ? new Date(r.submitted_at).toLocaleString() : "-"}
                      </td>
                      <td className="px-4 py-3"><span className="inline-block px-2 py-0.5 rounded bg-gold/15 text-navy text-xs font-medium">{r.form_type}</span></td>
                      <td className="px-4 py-3 font-medium text-navy">{r.full_name || "-"}</td>
                      <td className="px-4 py-3"><a href={`mailto:${r.email}`} className="text-navy hover:text-gold">{r.email}</a></td>
                      <td className="px-4 py-3">{r.organization || "-"}</td>
                      <td className="px-4 py-3">{r.topic || "-"}</td>
                      <td className="px-4 py-3 max-w-[360px]">
                        <div className="line-clamp-3 whitespace-pre-wrap">{r.message || "-"}</div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Button size="sm" variant="outline" onClick={() => setSelected(r)}>
                          <Eye className="h-4 w-4 mr-1" /> View
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-navy">
              {selected?.full_name || "Submission"}
            </DialogTitle>
            <DialogDescription>
              {selected?.form_type}{" "}
              {selected?.submitted_at && `· ${new Date(selected.submitted_at).toLocaleString()}`}
            </DialogDescription>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Email</div>
                  <a href={`mailto:${selected.email}`} className="text-navy hover:text-gold break-all">
                    {selected.email || "-"}
                  </a>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Organization</div>
                  <div>{selected.organization || "-"}</div>
                </div>
                <div className="sm:col-span-2">
                  <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Topic</div>
                  <div>{selected.topic || "-"}</div>
                </div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Message</div>
                <div className="whitespace-pre-wrap rounded-md border border-border bg-muted/30 p-3">
                  {selected.message || "-"}
                </div>
              </div>
              {selected.extra_json && selected.extra_json !== "{}" && (
                <div>
                  <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Extra data</div>
                  <pre className="whitespace-pre-wrap break-all rounded-md border border-border bg-muted/30 p-3 text-xs">
{(() => { try { return JSON.stringify(JSON.parse(selected.extra_json), null, 2); } catch { return selected.extra_json; } })()}
                  </pre>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default Admin;