import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import partnershipsImg from "@/assets/aims-partnerships.jpg";
import bgNetwork from "@/assets/bg-network.png";

const Partnerships = () => (
  <main className="min-h-screen bg-background">
    <Nav />
    <section id="partnerships" className="bg-gray-light text-navy relative pt-44 pb-24 md:pt-52 md:pb-32 overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-center bg-cover opacity-[0.06] mix-blend-multiply"
        style={{ backgroundImage: `url(${bgNetwork})` }}
      />
      <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10">
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10 bg-gold" />
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Partnerships</span>
          </div>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.05] whitespace-pre-line">
            {"Position Within Global \nInvestment Pipeline"}
          </h1>
          <p className="mt-6 text-lg text-navy/70 whitespace-pre-line">
            {"We partner with practitioners, organizations, institutions and other global stakeholders within the investment mobilization sector to advance the systems, stewardship, and institutional architecture required to convert global opportunities into sustainable global prosperity outcomes.\nGet early access to investment opportunities, secure the right capital for your projects, engage with investors and decision-makers, obtain high-level industry intelligence, and secure strategic positioning in emerging deals."}
          </p>
        </div>
        <div className="grid lg:grid-cols-2 gap-10 items-center mb-12">
          <div className="relative order-2 lg:order-1">
            <div className="absolute -inset-2 bg-gold/10 rounded-2xl blur-2xl" />
            <img
              src={partnershipsImg}
              alt="Executives sealing a strategic partnership"
              loading="lazy"
              className="relative w-full rounded-2xl shadow-elegant border border-navy/10 object-cover aspect-[4/3]"
            />
          </div>
          <div className="grid gap-4 order-1 lg:order-2">
            {["Strategic Partners", "Program Partners", "Capital Partners"].map((p, i) => (
              <div key={p} className="bg-white p-8 rounded-2xl shadow-elegant flex items-center gap-6">
                <span className="font-serif text-gold text-2xl">0{i + 1}</span>
                <h3 className="text-xl font-bold text-navy">{p}</h3>
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <p className="text-xl font-serif italic text-navy">This is not sponsorship, it is participation in an investment ecosystem.</p>
          <Button variant="navyOutline" size="lg" asChild>
            <Link to="/contact?topic=partnerships">Become a Partner <ArrowRight /></Link>
          </Button>
        </div>
      </div>
    </section>
    <Footer />
  </main>
);

export default Partnerships;
