import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, Briefcase, Building2, CalendarDays, Check, GraduationCap, Handshake, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { toast } from "@/hooks/use-toast";
import { submitForm } from "@/lib/submitForm";

type PathKey = "fellowship" | "investor" | "partnership";

const PATHS: Record<PathKey, { title: string; subtitle: string; icon: typeof GraduationCap; accent: string }> = {
  fellowship: {
    title: "Fellowship Application",
    subtitle: "For leaders building investment-ready pipelines.",
    icon: GraduationCap,
    accent: "Fellowship",
  },
  investor: {
    title: "Investor  Registration",
    subtitle: "For capital providers seeking viable and vetted opportunities.",
    icon: TrendingUp,
    accent: "Capital",
  },
  partnership: {
    title: "Partnership/Sponsorship",
    subtitle: "For institutions and brands seeking strategic positioning.",
    icon: Handshake,
    accent: "Partnership",
  },
};

const SECTORS = ["Infrastructure", "Energy", "Housing", "Transport", "Agriculture", "Industrial Development", "Technology"];

const PathChooser = () => (
  <div className="min-h-screen bg-gray-light">
    <Nav />
    <section className="pt-32 pb-24">
      <div className="max-w-[1100px] mx-auto px-6 lg:px-10">
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10 bg-gold" />
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Registration</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-navy mb-5 leading-[1.05]">Choose your pathway</h1>
          <p className="text-lg text-gray-medium leading-relaxed">
            Join a global, neutral platform and ecosystem for the advancement of investment mobilization principles, practices, standards, and institutional capabilities. Select the entry point that aligns with your current role/needs.
          </p>
          <div className="flex flex-wrap gap-x-6 gap-y-2 mt-6 text-sm text-gray-medium">
            <span>• Takes less than 3 minutes</span>
            <span>• Confidential & selective process</span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {(Object.keys(PATHS) as PathKey[]).map((key) => {
            const p = PATHS[key];
            return (
              <Link
                key={key}
                to={`/register/${key}`}
                className="group bg-white border border-border rounded-2xl p-8 hover:shadow-elegant hover:-translate-y-1 transition-all"
              >
                <div className="h-12 w-12 rounded-xl bg-navy text-gold flex items-center justify-center mb-6 group-hover:bg-gold group-hover:text-navy transition-colors">
                  <p.icon className="h-6 w-6" />
                </div>
                <span className="text-gold text-xs uppercase tracking-[0.2em] font-semibold">{p.accent}</span>
                <h2 className="text-xl font-bold text-navy mt-2 mb-3 leading-tight">{p.title}</h2>
                <p className="text-sm text-gray-medium leading-relaxed mb-6">{p.subtitle}</p>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-navy group-hover:text-gold transition-colors">
                  Begin <ArrowRight className="h-4 w-4" />
                </span>
              </Link>
            );
          })}

          {[
            {
              to: "/opportunities",
              icon: Briefcase,
              accent: "Opportunities",
              title: "Opportunity Submission",
              subtitle: "For project promoters seeking strategic, global capital.",
            },
            {
              to: "/summit",
              icon: CalendarDays,
              accent: "Convenings",
              title: "Attend a Convening",
              subtitle: "Explore opportunities. Engage investors. Empower dreams.",
            },
            {
              to: "/institute",
              icon: Building2,
              accent: "Institute",
              title: "Attend the Institute",
              subtitle: "The world’s leading learning platform on investment mobilization.",
            },
          ].map((c) => {
            const Icon = c.icon;
            return (
              <Link
                key={c.title}
                to={c.to}
                className="group bg-white border border-border rounded-2xl p-8 hover:shadow-elegant hover:-translate-y-1 transition-all"
              >
                <div className="h-12 w-12 rounded-xl bg-navy text-gold flex items-center justify-center mb-6 group-hover:bg-gold group-hover:text-navy transition-colors">
                  <Icon className="h-6 w-6" />
                </div>
                <span className="text-gold text-xs uppercase tracking-[0.2em] font-semibold">{c.accent}</span>
                <h2 className="text-xl font-bold text-navy mt-2 mb-3 leading-tight">{c.title}</h2>
                <p className="text-sm text-gray-medium leading-relaxed mb-6">{c.subtitle}</p>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-navy group-hover:text-gold transition-colors">
                  Begin <ArrowRight className="h-4 w-4" />
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
    <Footer />
  </div>
);

const Field = ({ label, required, children, hint }: { label: string; required?: boolean; children: React.ReactNode; hint?: string }) => (
  <div className="space-y-2">
    <Label className="text-sm font-medium text-navy">
      {label} {required && <span className="text-gold">*</span>}
    </Label>
    {children}
    {hint && <p className="text-xs text-gray-medium">{hint}</p>}
  </div>
);

const SectorPicker = ({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) => (
  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
    {SECTORS.map((s) => {
      const checked = value.includes(s);
      return (
        <button
          key={s}
          type="button"
          onClick={() => onChange(checked ? value.filter((x) => x !== s) : [...value, s])}
          className={`text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
            checked ? "border-gold bg-gold/10 text-navy font-semibold" : "border-border bg-white text-gray-medium hover:border-gold/50"
          }`}
        >
          {s}
        </button>
      );
    })}
  </div>
);

type FormState = Record<string, any>;

const StepShell = ({
  path,
  step,
  totalSteps,
  title,
  subtitle,
  children,
  onBack,
  onNext,
  nextLabel = "Next",
  canBack,
  isFinal,
}: {
  path: PathKey;
  step: number;
  totalSteps: number;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onBack: () => void;
  onNext: () => void;
  nextLabel?: string;
  canBack: boolean;
  isFinal?: boolean;
}) => {
  const Icon = PATHS[path].icon;
  const pct = ((step + 1) / totalSteps) * 100;
  return (
    <div className="min-h-screen bg-gray-light">
      <Nav />
      <section className="pt-28 pb-20">
        <div className="max-w-[820px] mx-auto px-6">
          <Link to="/register" className="inline-flex items-center gap-2 text-sm text-gray-medium hover:text-navy mb-6">
            <ArrowLeft className="h-4 w-4" /> Choose a different pathway
          </Link>

          <div className="bg-white rounded-2xl shadow-elegant border border-border overflow-hidden">
            <div className="p-8 md:p-10 border-b border-border">
              <div className="flex items-center gap-3 mb-3">
                <div className="h-9 w-9 rounded-lg bg-navy text-gold flex items-center justify-center">
                  <Icon className="h-5 w-5" />
                </div>
                <span className="text-xs uppercase tracking-[0.2em] font-semibold text-gold">{PATHS[path].accent}</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-navy leading-tight">{PATHS[path].title}</h1>
              <div className="mt-6">
                <div className="flex items-center justify-between mb-2 text-xs uppercase tracking-wider text-gray-medium font-semibold">
                  <span>Step {step + 1} of {totalSteps}</span>
                  <span>{Math.round(pct)}%</span>
                </div>
                <Progress value={pct} className="h-1.5 bg-gray-light" />
              </div>
            </div>

            <div className="p-8 md:p-10">
              <h2 className="text-xl md:text-2xl font-bold text-navy mb-2">{title}</h2>
              {subtitle && <p className="text-gray-medium mb-8">{subtitle}</p>}
              <div className="space-y-6">{children}</div>
            </div>

            <div className="px-8 md:px-10 py-6 bg-gray-light flex items-center justify-between">
              <Button variant="ghost" onClick={onBack} disabled={!canBack}>
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <Button variant={isFinal ? "gold" : "default"} size="lg" onClick={onNext} className={isFinal ? "" : "bg-navy text-white hover:bg-navy/90"}>
                {nextLabel} {!isFinal && <ArrowRight className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <p className="text-center text-xs text-gray-medium mt-6">
            Confidential & selective process · Your information is reviewed by the AIMS team
          </p>
        </div>
      </section>
      <Footer />
    </div>
  );
};

const Confirmation = ({ path }: { path: PathKey }) => (
  <div className="min-h-screen bg-gray-light">
    <Nav />
    <section className="pt-32 pb-24">
      <div className="max-w-[720px] mx-auto px-6 text-center">
        <div className="mx-auto h-16 w-16 rounded-full bg-gold/15 text-gold flex items-center justify-center mb-8">
          <Check className="h-8 w-8" />
        </div>
        <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">{PATHS[path].accent}</span>
        <h1 className="text-4xl md:text-5xl font-bold text-navy mt-4 mb-6 leading-[1.1]">
          Thank you, your submission has been <span className="italic">received</span>.
        </h1>
        <p className="text-lg text-gray-medium leading-relaxed mb-10">
          We appreciate your interest in AIMS. A member of our team will review your application
          and be in touch with you shortly regarding next steps.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button variant="navyOutline" asChild><Link to="/">Return Home</Link></Button>
          <Button variant="gold" asChild><Link to="/register">Submit Another</Link></Button>
        </div>
      </div>
    </section>
    <Footer />
  </div>
);

/* ------------ STEP DEFINITIONS ------------ */

type StepDef = {
  title: string;
  subtitle?: string;
  render: (f: FormState, set: (k: string, v: any) => void) => React.ReactNode;
  validate?: (f: FormState) => string | null;
};

const identityStep: StepDef = {
  title: "Tell us about you",
  subtitle: "Basic identity information.",
  render: (f, set) => (
    <>
      <Field label="Full Name" required>
        <Input value={f.fullName ?? ""} onChange={(e) => set("fullName", e.target.value)} placeholder="Jane Doe" maxLength={100} />
      </Field>
      <Field label="Email Address" required>
        <Input type="email" value={f.email ?? ""} onChange={(e) => set("email", e.target.value)} placeholder="you@org.com" maxLength={255} />
      </Field>
      <Field label="Phone Number" required hint="Include country code, e.g. +234 ...">
        <Input value={f.phone ?? ""} onChange={(e) => set("phone", e.target.value)} placeholder="+254 700 000 000" maxLength={32} />
      </Field>
      <Field label="Country" required>
        <Input value={f.country ?? ""} onChange={(e) => set("country", e.target.value)} placeholder="Country of residence" maxLength={80} />
      </Field>
    </>
  ),
  validate: (f) => {
    if (!f.fullName?.trim()) return "Please enter your full name.";
    if (!f.email?.trim() || !/^\S+@\S+\.\S+$/.test(f.email)) return "Please enter a valid email.";
    if (!f.phone?.trim() || f.phone.replace(/\D/g, "").length < 7) return "Please enter a valid phone number.";
    if (!f.country?.trim()) return "Please enter your country.";
    return null;
  },
};


const profileStep: StepDef = {
  title: "Your role & organization",
  render: (f, set) => (
    <>
      <Field label="Organization" required>
        <Input value={f.organization ?? ""} onChange={(e) => set("organization", e.target.value)} maxLength={140} />
      </Field>
      <Field label="Job Title / Role" required>
        <Input value={f.role ?? ""} onChange={(e) => set("role", e.target.value)} maxLength={140} />
      </Field>
      <Field label="Participant Type" required>
        <Select value={f.participantType ?? ""} onValueChange={(v) => set("participantType", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["Government", "Private Sector", "Investor / Capital Provider", "Development Organization", "Other"].map((o) => (
              <SelectItem key={o} value={o}>{o}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>
    </>
  ),
  validate: (f) => {
    if (!f.organization?.trim()) return "Organization is required.";
    if (!f.role?.trim()) return "Role is required.";
    if (!f.participantType) return "Please select participant type.";
    return null;
  },
};

const sectorsStep: StepDef = {
  title: "Sectors of interest",
  subtitle: "Select all that apply.",
  render: (f, set) => <SectorPicker value={f.sectors ?? []} onChange={(v) => set("sectors", v)} />,
  validate: (f) => (f.sectors?.length ? null : "Select at least one sector."),
};

/* Fellowship-specific */
const fellowshipBackgroundStep: StepDef = {
  title: "Professional background",
  render: (f, set) => (
    <>
      <Field label="Years of Experience" required>
        <Select value={f.years ?? ""} onValueChange={(v) => set("years", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["0–3", "4–7", "8–12", "13–20", "20+"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Current Responsibilities" required>
        <Textarea value={f.responsibilities ?? ""} onChange={(e) => set("responsibilities", e.target.value)} maxLength={500} rows={3} />
      </Field>
      <Field label="Previous roles (optional)">
        <Textarea value={f.previousRoles ?? ""} onChange={(e) => set("previousRoles", e.target.value)} maxLength={500} rows={3} />
      </Field>
    </>
  ),
  validate: (f) => {
    if (!f.years) return "Please select years of experience.";
    if (!f.responsibilities?.trim()) return "Please describe your current responsibilities.";
    return null;
  },
};

const fellowshipReadinessStep: StepDef = {
  title: "Investment readiness",
  subtitle: "Tell us about your current pipeline, if any.",
  render: (f, set) => (
    <>
      <Field label="Do you currently have an investment project / pipeline?" required>
        <RadioGroup value={f.hasPipeline ?? ""} onValueChange={(v) => set("hasPipeline", v)} className="flex gap-6">
          <label className="flex items-center gap-2 cursor-pointer"><RadioGroupItem value="yes" /> Yes</label>
          <label className="flex items-center gap-2 cursor-pointer"><RadioGroupItem value="no" /> No</label>
        </RadioGroup>
      </Field>
      {f.hasPipeline === "yes" && (
        <>
          <Field label="Brief description" hint="Max 200 words" required>
            <Textarea value={f.pipelineDesc ?? ""} onChange={(e) => set("pipelineDesc", e.target.value)} rows={4} maxLength={1500} />
          </Field>
          <Field label="Estimated project value" required>
            <Select value={f.projectValue ?? ""} onValueChange={(v) => set("projectValue", v)}>
              <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
              <SelectContent>
                {["<$1M", "$1M–$10M", "$10M–$50M", "$50M–$200M", "$200M+"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Stage" required>
            <Select value={f.stage ?? ""} onValueChange={(v) => set("stage", v)}>
              <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
              <SelectContent>
                {["Idea", "Early development", "Structuring", "Investment-ready"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
        </>
      )}
    </>
  ),
  validate: (f) => {
    if (!f.hasPipeline) return "Please answer this question.";
    if (f.hasPipeline === "yes") {
      if (!f.pipelineDesc?.trim()) return "Please provide a brief description.";
      if (!f.projectValue) return "Please select estimated value.";
      if (!f.stage) return "Please select a stage.";
    }
    return null;
  },
};

const fellowshipObjectiveStep: StepDef = {
  title: "Objective & commitment",
  render: (f, set) => (
    <>
      <Field label="What do you hope to achieve from THE Fellowship?" required>
        <Textarea value={f.objective ?? ""} onChange={(e) => set("objective", e.target.value)} rows={4} maxLength={1000} />
      </Field>
      <Field label="Can you commit to full participation (Oct 1–3)?" required>
        <RadioGroup value={f.commitment ?? ""} onValueChange={(v) => set("commitment", v)} className="flex gap-6">
          <label className="flex items-center gap-2 cursor-pointer"><RadioGroupItem value="yes" /> Yes</label>
          <label className="flex items-center gap-2 cursor-pointer"><RadioGroupItem value="no" /> No</label>
        </RadioGroup>
      </Field>
      <Field label="How did you hear about us? (optional)">
        <Input value={f.referral ?? ""} onChange={(e) => set("referral", e.target.value)} maxLength={140} />
      </Field>
    </>
  ),
  validate: (f) => {
    if (!f.objective?.trim()) return "Please describe your objective.";
    if (!f.commitment) return "Please confirm your availability.";
    return null;
  },
};

/* Investor-specific */
const investorProfileStep: StepDef = {
  title: "Investment profile",
  render: (f, set) => (
    <>
      <Field label="Type of Capital" required>
        <Select value={f.capitalType ?? ""} onValueChange={(v) => set("capitalType", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["Institutional", "Private Equity", "Venture", "Sovereign", "Family Office"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Typical Investment Size" required>
        <Select value={f.ticketSize ?? ""} onValueChange={(v) => set("ticketSize", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["<$5M", "$5M–$50M", "$50M–$200M", "$200M+"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Geographic Focus" required>
        <RadioGroup value={f.geo ?? ""} onValueChange={(v) => set("geo", v)} className="flex flex-col gap-3">
          <label className="flex items-center gap-2 cursor-pointer"><RadioGroupItem value="all" /> Africa (All)</label>
          <label className="flex items-center gap-2 cursor-pointer"><RadioGroupItem value="specific" /> Specific countries</label>
        </RadioGroup>
      </Field>
      {f.geo === "specific" && (
        <Field label="Which countries?" required>
          <Input value={f.geoCountries ?? ""} onChange={(e) => set("geoCountries", e.target.value)} placeholder="Kenya, Nigeria, Egypt…" maxLength={200} />
        </Field>
      )}
    </>
  ),
  validate: (f) => {
    if (!f.capitalType) return "Select capital type.";
    if (!f.ticketSize) return "Select ticket size.";
    if (!f.geo) return "Select geographic focus.";
    if (f.geo === "specific" && !f.geoCountries?.trim()) return "List target countries.";
    return null;
  },
};

const investorInterestStep: StepDef = {
  title: "Interest & engagement",
  render: (f, set) => (
    <>
      <Field label="What type of opportunities are you seeking?" required>
        <Textarea value={f.opportunities ?? ""} onChange={(e) => set("opportunities", e.target.value)} rows={4} maxLength={1000} />
      </Field>
      <Field label="Engagement Level (select all)">
        <div className="space-y-3">
          {["Viewing pipelines", "Participating in AIMS", "Strategic partnerships"].map((o) => {
            const checked = (f.engagement ?? []).includes(o);
            return (
              <label key={o} className="flex items-center gap-3 cursor-pointer">
                <Checkbox checked={checked} onCheckedChange={(v) => {
                  const cur: string[] = f.engagement ?? [];
                  set("engagement", v ? [...cur, o] : cur.filter((x) => x !== o));
                }} />
                <span className="text-sm text-navy">{o}</span>
              </label>
            );
          })}
        </div>
      </Field>
    </>
  ),
  validate: (f) => (!f.opportunities?.trim() ? "Please describe the opportunities you seek." : null),
};

/* Partnership-specific */
const partnershipOrgStep: StepDef = {
  title: "Organization profile",
  render: (f, set) => (
    <>
      <Field label="Organization Type" required>
        <Select value={f.orgType ?? ""} onValueChange={(v) => set("orgType", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["Bank", "DFI", "Corporate", "Advisory", "Other"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Partnership Type" required>
        <Select value={f.partnershipType ?? ""} onValueChange={(v) => set("partnershipType", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["Strategic", "Program", "Capital", "Sponsorship"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
    </>
  ),
  validate: (f) => {
    if (!f.orgType) return "Select organization type.";
    if (!f.partnershipType) return "Select partnership type.";
    return null;
  },
};

const partnershipObjectiveStep: StepDef = {
  title: "Objective & budget",
  render: (f, set) => (
    <>
      <Field label="What are you looking to achieve through AIMS?" required>
        <Textarea value={f.partnerObjective ?? ""} onChange={(e) => set("partnerObjective", e.target.value)} rows={4} maxLength={1000} />
      </Field>
      <Field label="Budget Range" required>
        <Select value={f.budget ?? ""} onValueChange={(v) => set("budget", v)}>
          <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
          <SelectContent>
            {["<$25K", "$25K–$50K", "$50K–$100K", "$100K+"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
    </>
  ),
  validate: (f) => {
    if (!f.partnerObjective?.trim()) return "Please describe your objective.";
    if (!f.budget) return "Please select a budget range.";
    return null;
  },
};

const reviewStep = (path: PathKey): StepDef => ({
  title: "Review & submit",
  subtitle: "Confirm the details below before submitting.",
  render: (f) => (
    <div className="bg-gray-light rounded-xl p-6 space-y-3 text-sm">
      <p className="text-navy"><span className="text-gray-medium">Pathway:</span> <strong>{PATHS[path].title}</strong></p>
      <p className="text-navy"><span className="text-gray-medium">Name:</span> {f.fullName}</p>
      <p className="text-navy"><span className="text-gray-medium">Email:</span> {f.email}</p>
      <p className="text-navy"><span className="text-gray-medium">Organization:</span> {f.organization}, {f.role}</p>
      {f.sectors?.length > 0 && (
        <p className="text-navy"><span className="text-gray-medium">Sectors:</span> {f.sectors.join(", ")}</p>
      )}
      <p className="text-xs text-gray-medium pt-3 border-t border-border">
        By submitting, you confirm the information is accurate. The AIMS team reviews each application.
      </p>
    </div>
  ),
});

/* ------------ STEP COMPOSITIONS ------------ */

const STEPS: Record<PathKey, StepDef[]> = {
  fellowship: [
    identityStep,
    profileStep,
    sectorsStep,
    fellowshipBackgroundStep,
    fellowshipReadinessStep,
    fellowshipObjectiveStep,
    reviewStep("fellowship"),
  ],
  investor: [
    identityStep,
    profileStep,
    sectorsStep,
    investorProfileStep,
    investorInterestStep,
    reviewStep("investor"),
  ],
  partnership: [
    identityStep,
    profileStep,
    sectorsStep,
    partnershipOrgStep,
    partnershipObjectiveStep,
    reviewStep("partnership"),
  ],
};

const STORAGE_KEY = (path: PathKey) => `aims_register_${path}`;

const Wizard = ({ path }: { path: PathKey }) => {
  const navigate = useNavigate();
  const steps = useMemo(() => STEPS[path], [path]);
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormState>({});
  const [done, setDone] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY(path));
      if (raw) {
        const saved = JSON.parse(raw);
        setForm(saved.form ?? {});
        setStep(Math.min(saved.step ?? 0, steps.length - 1));
      }
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path]);

  useEffect(() => {
    if (done) return;
    localStorage.setItem(STORAGE_KEY(path), JSON.stringify({ form, step }));
  }, [form, step, path, done]);

  const set = (k: string, v: any) => setForm((p) => ({ ...p, [k]: v }));
  const current = steps[step];
  const isFinal = step === steps.length - 1;

  const handleNext = async () => {
    const err = current.validate?.(form);
    if (err) {
      toast({ title: "Please complete this step", description: err, variant: "destructive" });
      return;
    }
    if (isFinal) {
      try {
        const { fullName, email, organization, ...rest } = form;
        await submitForm({
          form_type: `register_${path}`,
          full_name: fullName ?? "",
          email: email ?? "",
          organization: organization ?? "",
          topic: PATHS[path].title,
          message: rest.objective ?? rest.opportunities ?? rest.partnerObjective ?? "",
          extra: rest,
        });
      } catch {
        toast({
          title: "Submission failed",
          description: "We couldn't submit your application. Please try again shortly.",
          variant: "destructive",
        });
        return;
      }
      localStorage.removeItem(STORAGE_KEY(path));
      setDone(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setStep((s) => s + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    if (step === 0) {
      navigate("/register");
      return;
    }
    setStep((s) => s - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (done) return <Confirmation path={path} />;

  return (
    <StepShell
      path={path}
      step={step}
      totalSteps={steps.length}
      title={current.title}
      subtitle={current.subtitle}
      onBack={handleBack}
      onNext={handleNext}
      canBack={true}
      isFinal={isFinal}
      nextLabel={isFinal ? "Submit Application" : "Next"}
    >
      {current.render(form, set)}
    </StepShell>
  );
};

const Register = () => {
  const { path } = useParams<{ path?: string }>();
  if (!path) return <PathChooser />;
  if (!(path in PATHS)) return <PathChooser />;
  return <Wizard path={path as PathKey} />;
};

export default Register;