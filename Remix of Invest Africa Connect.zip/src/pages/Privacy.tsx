import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";

const sections = [
  {
    title: "1. Information We Collect",
    body: "We collect information you provide directly, including your name, email, organization, and any messages submitted through forms on this site. We also collect basic analytics data such as pages visited, device type, and approximate location to improve the platform.",
  },
  {
    title: "2. How We Use Your Information",
    body: "Information is used to respond to inquiries, process Fellowship and Summit applications, send relevant updates about AIMS programs, and improve our content and services. We do not sell your personal data.",
  },
  {
    title: "3. Sharing & Disclosure",
    body: "We share information only with trusted partners who help us operate the platform (e.g. email providers, analytics) under appropriate confidentiality terms, or when required by law.",
  },
  {
    title: "4. Data Retention",
    body: "We retain your information only as long as necessary to fulfill the purposes outlined in this policy, comply with legal obligations, and resolve disputes.",
  },
  {
    title: "5. Your Rights",
    body: "You may request access, correction, or deletion of your personal data at any time by contacting us at privacy@aims-africa.org.",
  },
  {
    title: "6. Updates",
    body: "We may update this policy periodically. Material changes will be communicated through the platform or via email.",
  },
];

const Privacy = () => (
  <div className="min-h-screen bg-background">
    <Nav />
    <section className="gradient-hero text-white pt-32 pb-20">
      <div className="max-w-[900px] mx-auto px-6 lg:px-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-px w-10 bg-gold" />
          <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Legal</span>
        </div>
        <h1 className="text-5xl md:text-6xl font-bold leading-[1.05] mb-6">Privacy Policy</h1>
        <p className="text-white/70 text-lg">Last updated: April 2026</p>
      </div>
    </section>
    <section className="py-20">
      <div className="max-w-[900px] mx-auto px-6 lg:px-10 space-y-10">
        <p className="text-lg text-foreground/80 leading-relaxed">
          AIMS, Africa Investment Mobilization Summit ("AIMS", "we", "our") respects your privacy.
          This policy describes how we collect, use, and protect information when you interact with
          our website, programs, and convenings.
        </p>
        {sections.map((s) => (
          <div key={s.title}>
            <h2 className="font-serif text-2xl font-bold text-navy mb-3">{s.title}</h2>
            <p className="text-foreground/75 leading-relaxed">{s.body}</p>
          </div>
        ))}
        <div className="pt-6 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Questions about this policy? Contact{" "}
            <a href="mailto:privacy@aims-africa.org" className="text-navy underline hover:text-gold">
              privacy@aims-africa.org
            </a>.
          </p>
        </div>
      </div>
    </section>
    <Footer />
  </div>
);

export default Privacy;