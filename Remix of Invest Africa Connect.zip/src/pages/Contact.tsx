import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { z } from "zod";
import { Mail, MapPin, Phone, ArrowRight, CheckCircle2, FileText } from "lucide-react";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { submitForm } from "@/lib/submitForm";

const contactSchema = z.object({
  fullName: z.string().trim().min(1, "Please enter your name").max(100),
  email: z.string().trim().email("Please enter a valid email").max(255),
  phone: z.string().trim().min(7, "Please enter a valid phone number").max(32),
  organization: z.string().trim().max(150).optional().or(z.literal("")),
  topic: z.string().min(1, "Please select a topic"),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(1000),
});


const channels = [
  { icon: Mail, label: "General", value: "info@investmentmobilization.org", href: "mailto:info@investmentmobilization.org" },
];

const Contact = () => {
  const [searchParams] = useSearchParams();
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", organization: "", topic: "", message: "" });
  const [submitting, setSubmitting] = useState(false);
  const isPartnership = form.topic === "partnerships";

  useEffect(() => {
    const topic = searchParams.get("topic");
    const valid = ["fellowship", "summit", "partnerships", "press", "general"];
    if (topic && valid.includes(topic)) {
      setForm((f) => (f.topic ? f : { ...f, topic }));
    }
  }, [searchParams]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = contactSchema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please review the form");
      return;
    }
    setSubmitting(true);
    try {
      await submitForm({
        form_type: "contact",
        full_name: form.fullName,
        email: form.email,
        organization: form.organization,
        topic: form.topic,
        message: form.message,
        extra: { phone: form.phone },
      });
      toast.success("Thank you, your message has been received.", {
        description: "A member of our team will be in touch with you shortly.",
      });
      setForm({ fullName: "", email: "", phone: "", organization: "", topic: "", message: "" });

    } catch (err) {
      toast.error("We couldn't submit your message. Please try again shortly.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <section className="gradient-hero text-white pt-32 pb-20">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-10 bg-gold" />
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Contact</span>
          </div>
          <h1 className="text-5xl font-bold leading-[1.05] mb-6 max-w-3xl md:text-5xl">
            From potential to prosperity.<br />
            From opportunities to outcomes.
          </h1>
          <p className="text-white/75 text-lg max-w-2xl whitespace-pre-line">
            Let’s collaborate to consistently close the investment conversion gap.{"\n"}
            Let’s partner-to-prosper us.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-10 grid lg:grid-cols-[1fr_1.4fr] gap-14">
          <div>
            <h2 className="font-serif text-3xl font-bold text-navy mb-8">Direct Channels</h2>
            <ul className="space-y-6">
              {channels.map((c) => (
                <li key={c.label} className="flex gap-4">
                  <div className="h-10 w-10 rounded-md bg-navy/5 flex items-center justify-center shrink-0">
                    <c.icon className="h-5 w-5 text-navy" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">{c.label}</p>
                    {c.href ? (
                      <a href={c.href} className="text-navy hover:text-gold transition-colors">{c.value}</a>
                    ) : (
                      <p className="text-navy">{c.value}</p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <form onSubmit={onSubmit} className="bg-white border border-border rounded-xl p-8 md:p-10 shadow-sm space-y-5">
            <h2 className="font-serif text-2xl font-bold text-navy mb-2">Send a message</h2>
            {isPartnership && (
              <div className="rounded-lg border border-gold/40 bg-gold/5 p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-gold" />
                  <p className="text-xs uppercase tracking-[0.2em] font-semibold text-navy">
                    Partner Eligibility & Requirements
                  </p>
                </div>
                <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3">
                  {[
                    "Institutional capital allocator, DFI, government body, corporate, or ecosystem enabler",
                    "Active mandate or programmatic interest in African markets",
                    "Authorized signatory or senior decision-maker as primary contact",
                    "Willingness to commit to a multi-year engagement or summit cycle",
                    "Brief overview of your strategic objectives in the message field",
                    "Compliance with AIMS partnership code of conduct and disclosure standards",
                  ].map((item) => (
                    <div key={item} className="flex gap-2 text-sm text-navy/80 leading-snug">
                      <CheckCircle2 className="h-4 w-4 text-gold shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-navy/60">
                  Submissions are reviewed by the Partnerships Office. Selected partners receive a tailored engagement
                  proposal within 5–7 business days.
                </p>
              </div>
            )}
            <div className="grid md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full name</Label>
                <Input id="fullName" value={form.fullName} maxLength={100}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={form.email} maxLength={255}
                  onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone number</Label>
                <Input id="phone" type="tel" value={form.phone} maxLength={32} placeholder="+254 700 000 000"
                  onChange={(e) => setForm({ ...form, phone: e.target.value })} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="organization">Organization (optional)</Label>
                <Input id="organization" value={form.organization} maxLength={150}
                  onChange={(e) => setForm({ ...form, organization: e.target.value })} />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="topic">Topic</Label>
              <Select value={form.topic} onValueChange={(v) => setForm({ ...form, topic: v })}>
                <SelectTrigger id="topic"><SelectValue placeholder="Select a topic" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="fellowship">THE Fellowship</SelectItem>
                  <SelectItem value="summit">AIMS Summit</SelectItem>
                  <SelectItem value="partnerships">Partnerships</SelectItem>
                  <SelectItem value="press">Press / Media</SelectItem>
                  <SelectItem value="general">General Inquiry</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" rows={5} maxLength={1000} value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })} required />
            </div>
            <Button type="submit" variant="gold" size="lg" disabled={submitting} className="w-full">
              {submitting ? "Sending..." : "Send message"} <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </form>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default Contact;