import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Users, Target, Layers, TrendingUp, Globe2, Award, BookOpen, Briefcase, Clock, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { toast } from "sonner";
import { submitForm } from "@/lib/submitForm";
import fellowshipImg from "@/assets/aims-fellowship.png";

const scrollToForm = () => {
  document.getElementById("apply")?.scrollIntoView({ behavior: "smooth", block: "start" });
};

const Hero = () => (
  <section className="relative gradient-hero text-white pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden">
    <div className="absolute inset-0 opacity-30">
      <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-gold/20 blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[hsl(var(--navy-light))] blur-[140px]" />
    </div>
    <div className="relative max-w-[1280px] mx-auto px-6 lg:px-10 grid lg:grid-cols-2 gap-16 items-center">
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="h-px w-10 bg-gold" />
          <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">THE Fellowship</span>
        </div>
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.02] mb-8">
          The Strategic Investment <span className="text-gold italic">Readiness</span> Accelerator <span className="text-gold italic">Fellowship</span>
        </h1>
        <p className="text-lg md:text-xl text-white/75 leading-relaxed mb-10 max-w-xl whitespace-pre-line">
          An intensive executive bootcamp where opportunities
          are structured into bankable projects and investment-ready pipelines,
          and project promoters aligned with global capital expectations.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button variant="gold" size="xl" onClick={scrollToForm}>
            APPLY TO THE FELLOWSHIP <ArrowRight className="ml-1" />
          </Button>
          <Button variant="goldOutline" size="xl" asChild>
            <a href="#curriculum">View Curriculum</a>
          </Button>
        </div>
      </div>
      <div className="relative">
        <div className="absolute inset-0 bg-gold/10 rounded-2xl blur-3xl" />
        <img
          src={fellowshipImg}
          alt="THE Fellowship executive cohort in strategic session"
          className="relative rounded-2xl shadow-elegant border border-gold/20 w-full"
        />
      </div>
    </div>
  </section>
);

const Eligibility = () => (
  <section id="eligibility" className="bg-background text-navy py-24 md:py-32">
    <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
      <div className="max-w-3xl mb-16">
        <div className="flex items-center gap-3 mb-5">
          <div className="h-px w-10 bg-gold" />
          <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Eligibility</span>
        </div>
        <h2 className="text-4xl md:text-5xl font-bold leading-[1.05] mb-6">Who the Fellowship Is For</h2>
        <p className="text-lg text-gray-medium leading-relaxed">
          The Fellowship is selective. We seek senior leaders in a position to influence pipeline development
          and capital deployment across Africa.
        </p>
      </div>
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {[
          { t: "Government Leaders", d: "Senior officials shaping investment policy, infrastructure pipelines, and PPPs.", icon: Globe2 },
          { t: "Private Developers", d: "Operators and enterprises with viable projects seeking structure and capital.", icon: Briefcase },
          { t: "Capital Mobilizers", d: "Executives at DFIs, funds, and institutions structuring African deal flow.", icon: TrendingUp },
        ].map((s) => (
          <div key={s.t} className="bg-white p-8 rounded-2xl border border-border hover:shadow-elegant transition-shadow">
            <s.icon className="h-10 w-10 text-gold mb-5" />
            <h3 className="text-xl font-bold text-navy mb-3">{s.t}</h3>
            <p className="text-gray-medium leading-relaxed">{s.d}</p>
          </div>
        ))}
      </div>
      <div className="bg-gray-light rounded-2xl p-10">
        <h3 className="font-bold text-navy mb-6 text-lg">Selection Criteria</h3>
        <ul className="grid md:grid-cols-2 gap-4">
          {[
            "Senior decision-making authority within your organization",
            "Active or potential investment pipeline or mandate",
            "Demonstrated commitment to African investment outcomes",
            "Capacity to engage capital partners post-program",
          ].map((c) => (
            <li key={c} className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-gold flex-shrink-0 mt-0.5" />
              <span className="text-gray-medium">{c}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  </section>
);

const Curriculum = () => {
  const tracks = [
    {
      n: "01",
      t: "Strategic Opportunity Mapping &\nInvestment Positioning",
      icon: Target,
      focus:
        "Identifying, framing, and positioning high-potential opportunities for global capital engagement.",
      description:
        "Participants learn how to evaluate opportunities through the lens of investor relevance, sector competitiveness, and long-term strategic value creation.",
      areas: [
        "Opportunity-to-Investment (O2I) Mapping",
        "Sector Prioritization",
        "Investment Positioning",
        "Capital Attraction Narratives",
        "Strategic Market Intelligence",
      ],
    },
    {
      n: "02",
      t: "Investment Readiness Diagnostics & Institutional Preparation",
      icon: Layers,
      focus:
        "Understanding why capital does not move and how to build institutional readiness for investment conversion.",
      description:
        "This module introduces practical frameworks for assessing project, ecosystem, and institutional readiness while identifying critical bottlenecks affecting capital deployment.",
      areas: [
        "Project Investment Readiness Frameworks",
        "Institutional Readiness Assessment",
        "Risk & Governance Analysis",
        "Investor Confidence Architecture",
        "Policy & Coordination Readiness",
      ],
    },
    {
      n: "03",
      t: "Capital Structuring, Deal Engineering & Mobilization Pathways",
      icon: TrendingUp,
      focus:
        "Transforming opportunities into financeable, transaction-capable investment propositions.",
      description:
        "Participants explore the strategic, financial, and stakeholder coordination processes required to structure and mobilize capital across complex environments.",
      areas: [
        "Capital Stack Design",
        "Blended Finance & PPPs",
        "Investor Mapping & Engagement",
        "Transaction Structuring",
        "Cross-Border Capital Coordination",
      ],
    },
    {
      n: "04",
      t: "Investment Mobilization Leadership &\nExecution Systems",
      icon: Users,
      focus:
        "Building long-horizon systems, institutions, and execution architectures for sustainable investment mobilization.",
      description:
        "The module focuses on leadership, ecosystem coordination, implementation strategy, and the future of investment mobilization governance.",
      areas: [
        "Investment Mobilization Systems",
        "Ecosystem Coordination",
        "Institutional Operating Models",
        "Strategic Partnerships",
        "Digital & AI-Enabled Mobilization Infrastructure",
      ],
    },
  ];

  const outcomes = [
    "Practical readiness assessment tools",
    "Strategic investment mobilization frameworks",
    "Investor engagement methodologies",
    "Institutional execution roadmaps",
    "A clearer understanding of how to convert opportunities into sustainable investment outcomes",
  ];

  const attendees = [
    "Government Officials",
    "Investment Promotion Agencies",
    "Infrastructure & PPP Units",
    "Sovereign & Development Institutions",
    "Family Offices & Private Investors",
    "Transaction Advisors",
    "Project Sponsors",
    "Ecosystem Builders",
    "Development Finance Stakeholders",
  ];

  return (
    <section id="curriculum" className="bg-navy text-white py-24 md:py-32">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-px w-10 bg-gold" />
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">
              SIRAF · CURRICULUM
            </span>
          </div>
          <p className="text-sm md:text-base uppercase tracking-[0.2em] text-white/80 font-semibold mb-6">
            Strategic Investment Readiness Accelerator Fellowship (SIRAF)
          </p>


          <h2 className="text-4xl md:text-5xl font-bold leading-[1.05] mb-6">
            Four Modules.<br />
            Integrated Tracks.<br />
            One Outcome.
          </h2>
          <p className="text-lg text-white/70 leading-relaxed">
            A structured journey from concept clarity to capital engagement, delivered through
            executive sessions, working clinics, and direct investor exposure.
          </p>
        </div>

        <p className="text-xs uppercase tracking-[0.25em] text-gold font-semibold mb-6">
          Core Fellowship Modules
        </p>
        <div className="grid md:grid-cols-2 gap-6">
          {tracks.map((t) => (
            <div key={t.n} className="bg-[hsl(var(--navy-light))] border border-white/5 p-8 rounded-2xl flex flex-col">
              <div className="flex items-center justify-between mb-6">
                <t.icon className="h-8 w-8 text-gold" />
                <span className="font-serif text-3xl text-white/20">{t.n}</span>
              </div>
              <h3 className="text-2xl font-bold mb-5 leading-snug whitespace-pre-line">{t.t}</h3>
              <p className="text-sm text-white/85 mb-3">
                <span className="text-gold font-semibold">Focus: </span>
                {t.focus}
              </p>
              <p className="text-sm text-white/70 leading-relaxed mb-6">{t.description}</p>
              <p className="text-xs uppercase tracking-[0.18em] text-white/50 font-semibold mb-3">Key Areas</p>
              <ul className="space-y-2">
                {t.areas.map((p) => (
                  <li key={p} className="flex items-start gap-3 text-white/80">
                    <CheckCircle2 className="h-4 w-4 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-sm leading-relaxed">{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mt-16">
          <div className="bg-[hsl(var(--navy-light))] border border-white/5 p-8 rounded-2xl">
            <div className="flex items-center gap-3 mb-5">
              <Award className="h-6 w-6 text-gold" />
              <h3 className="text-2xl font-bold">Fellowship Outcomes</h3>
            </div>
            <p className="text-sm text-white/70 mb-5">Participants will leave the Fellowship with:</p>
            <ul className="space-y-2">
              {outcomes.map((o) => (
                <li key={o} className="flex items-start gap-3 text-white/85">
                  <CheckCircle2 className="h-4 w-4 text-gold mt-0.5 flex-shrink-0" />
                  <span className="text-sm leading-relaxed">{o}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-[hsl(var(--navy-light))] border border-white/5 p-8 rounded-2xl">
            <div className="flex items-center gap-3 mb-5">
              <Users className="h-6 w-6 text-gold" />
              <h3 className="text-2xl font-bold">Who Should Attend</h3>
            </div>
            <ul className="grid sm:grid-cols-2 gap-x-4 gap-y-2">
              {attendees.map((a) => (
                <li key={a} className="flex items-start gap-3 text-white/85">
                  <CheckCircle2 className="h-4 w-4 text-gold mt-0.5 flex-shrink-0" />
                  <span className="text-sm leading-relaxed">{a}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

const Highlights = () => (
  <section className="bg-gray-light text-navy py-24 md:py-32">
    <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
      <div className="max-w-3xl mb-16">
        <div className="flex items-center gap-3 mb-5">
          <div className="h-px w-10 bg-gold" />
          <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Track Highlights</span>
        </div>
        <h2 className="text-4xl md:text-5xl font-bold leading-[1.05] mb-6">What Fellows Receive</h2>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { t: "Executive Sessions", d: "Closed-door briefings led by global investment practitioners.", icon: BookOpen },
          { t: "Project Clinics", d: "One-on-one structuring support on your specific opportunity.", icon: Layers },
          { t: "Investor Access", d: "Curated introductions and a guaranteed slot at the AIMS Summit.", icon: TrendingUp },
          { t: "Fellow Designation", d: "Status as a Fellow of THE Fellowship, recognized within Africa's investment ecosystem.", icon: Award },
        ].map((h) => (
          <div key={h.t} className="bg-white p-8 rounded-2xl border-t-4 border-gold">
            <h.icon className="h-8 w-8 text-navy mb-5" />
            <h3 className="text-lg font-bold mb-3">{h.t}</h3>
            <p className="text-sm text-gray-medium leading-relaxed">{h.d}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const ApplyForm = () => {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [orgType, setOrgType] = useState("");
  const [trackInterest, setTrackInterest] = useState("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!orgType || !trackInterest) {
      toast.error("Please select your organization type and track interest.");
      return;
    }
    const form = e.currentTarget;
    const fd = new FormData(form);
    setSubmitting(true);
    try {
      await submitForm({
        form_type: "register_fellowship",
        full_name: String(fd.get("fullName") || ""),
        email: String(fd.get("email") || ""),
        phone: String(fd.get("phone") || ""),
        organization: String(fd.get("org") || ""),
        organization_type: orgType,
        track_interest: trackInterest,
        message: String(fd.get("intent") || ""),
      });
      setSubmitted(true);
      toast.success("Interest registered. Our team will be in touch.");
    } catch {
      toast.error("Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <section id="apply" className="bg-background text-navy py-24 md:py-32">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <CheckCircle2 className="h-14 w-14 text-gold mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">Your interest has been received.</h2>
          <p className="text-lg text-gray-medium mb-8">
            We review all expressions of interest carefully. Our team will reach out with next steps
            on your full application.
          </p>
          <Button variant="navyOutline" size="lg" asChild>
            <Link to="/">Back to Home</Link>
          </Button>
        </div>
      </section>
    );
  }

  return (
    <section id="apply" className="bg-background text-navy py-24 md:py-32">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10 grid lg:grid-cols-5 gap-12">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10 bg-gold" />
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Apply</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold leading-[1.05] mb-6">Express Your Interest</h2>
          <p className="text-lg text-gray-medium leading-relaxed mb-8">
            Begin the conversation. Share a brief overview and our team will guide you through the
            full application process.
          </p>
          <ul className="space-y-3 text-sm text-gray-medium">
            <li className="flex gap-3"><CheckCircle2 className="h-4 w-4 text-gold mt-1 flex-shrink-0" /> Confidential & selective process</li>
            <li className="flex gap-3"><CheckCircle2 className="h-4 w-4 text-gold mt-1 flex-shrink-0" /> Less than 3 minutes to complete</li>
            <li className="flex gap-3"><CheckCircle2 className="h-4 w-4 text-gold mt-1 flex-shrink-0" /> Direct response from THE Fellowship team</li>
          </ul>
        </div>
        <form onSubmit={onSubmit} className="lg:col-span-3 bg-white border border-border rounded-2xl p-8 md:p-10 shadow-elegant space-y-5">
          <div>
            <Label htmlFor="fullName">Full Name</Label>
            <Input id="fullName" name="fullName" required className="mt-2" placeholder="Jane Doe" />
          </div>
          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="email">Work Email</Label>
              <Input id="email" name="email" type="email" required className="mt-2" placeholder="jane@org.com" />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" name="phone" type="tel" required className="mt-2" placeholder="+254 700 000 000" maxLength={32} />
            </div>
          </div>
          <div>
            <Label htmlFor="org">Organization</Label>
            <Input id="org" name="org" required className="mt-2" placeholder="Organization name" />
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="orgType">Organization Type</Label>
              <Select value={orgType} onValueChange={setOrgType}>
                <SelectTrigger id="orgType" className="mt-2">
                  <SelectValue placeholder="Select organization type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="government">Government / Public Sector</SelectItem>
                  <SelectItem value="dfi">DFI / Multilateral</SelectItem>
                  <SelectItem value="institutional-investor">Institutional Investor</SelectItem>
                  <SelectItem value="private-developer">Private Developer / Operator</SelectItem>
                  <SelectItem value="advisory">Advisory / Professional Services</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="track">Track Interest</Label>
              <Select value={trackInterest} onValueChange={setTrackInterest}>
                <SelectTrigger id="track" className="mt-2">
                  <SelectValue placeholder="Select a track" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public-sector">Public Sector</SelectItem>
                  <SelectItem value="private-sector">Private Sector</SelectItem>
                  <SelectItem value="ppp">Public-Private Partnership</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="intent">Short Message</Label>
            <Textarea id="intent" name="intent" required rows={4} className="mt-2" placeholder="Briefly describe your project, mandate, or what you hope to gain from the Fellowship." />
          </div>
          <Button type="submit" variant="gold" size="lg" disabled={submitting} className="w-full">
            {submitting ? "Submitting…" : "Submit Interest"} <ArrowRight />
          </Button>
          <p className="text-xs text-gray-medium text-center">
            Your submission is confidential and reviewed by THE Fellowship team.
          </p>
        </form>
      </div>
    </section>
  );
};

const Fellowship = () => (
  <main className="min-h-screen bg-background">
    <Nav />
    <Hero />
    
    <Curriculum />
    <Highlights />
    <ApplyForm />
    <Footer />
  </main>
);

export default Fellowship;
