import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";

const sections = [
  {
    title: "1. Acceptance of Terms",
    body: "By accessing or using the AIMS platform, programs, or convenings, you agree to be bound by these Terms of Service. If you do not agree, please discontinue use of the platform.",
  },
  {
    title: "2. Use of the Platform",
    body: "You agree to use the platform lawfully and respectfully. You may not attempt to disrupt, reverse-engineer, or misuse any part of the service or its content.",
  },
  {
    title: "3. Intellectual Property",
    body: "All content, including the AIMS name, brand identity, written materials, frameworks (such as SIRAF), and visuals, is owned by AIMS or its licensors. You may not reproduce or distribute it without written permission.",
  },
  {
    title: "4. Programs & Applications",
    body: "Acceptance into THE Fellowship, Summit, or any AIMS program is at our sole discretion. Submission of an application does not guarantee participation.",
  },
  {
    title: "5. Disclaimers",
    body: "The platform and its content are provided on an \"as-is\" basis. AIMS does not provide investment, legal, or financial advice. Engagements with partners and capital allocators are independent of AIMS.",
  },
  {
    title: "6. Limitation of Liability",
    body: "To the maximum extent permitted by law, AIMS shall not be liable for any indirect, incidental, or consequential damages arising from your use of the platform or programs.",
  },
  {
    title: "7. Governing Law",
    body: "These terms are governed by the laws of the Federal Republic of Nigeria, without regard to its conflict-of-law provisions.",
  },
];

const Terms = () => (
  <div className="min-h-screen bg-background">
    <Nav />
    <section className="gradient-hero text-white pt-32 pb-20">
      <div className="max-w-[900px] mx-auto px-6 lg:px-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-px w-10 bg-gold" />
          <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Legal</span>
        </div>
        <h1 className="text-5xl md:text-6xl font-bold leading-[1.05] mb-6">Terms of Service</h1>
        <p className="text-white/70 text-lg">Last updated: April 2026</p>
      </div>
    </section>
    <section className="py-20">
      <div className="max-w-[900px] mx-auto px-6 lg:px-10 space-y-10">
        <p className="text-lg text-foreground/80 leading-relaxed">
          These Terms govern your use of the AIMS website, THE Fellowship, the AIMS Summit,
          and any related services or convenings.
        </p>
        {sections.map((s) => (
          <div key={s.title}>
            <h2 className="font-serif text-2xl font-bold text-navy mb-3">{s.title}</h2>
            <p className="text-foreground/75 leading-relaxed">{s.body}</p>
          </div>
        ))}
        <div className="pt-6 border-t border-border">
          <p className="text-sm text-muted-foreground">
            For questions, contact{" "}
            <a href="mailto:legal@aims-africa.org" className="text-navy underline hover:text-gold">
              legal@aims-africa.org
            </a>.
          </p>
        </div>
      </div>
    </section>
    <Footer />
  </div>
);

export default Terms;