import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowRight, Check, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { toast } from "@/hooks/use-toast";
import { submitForm } from "@/lib/submitForm";

const SECTORS = ["Infrastructure", "Energy", "Housing", "Transport", "Agriculture", "Industrial Development", "Technology"];
const ATTENDEE_TYPES = [
  "Government",
  "Private Sector",
  "Institutional Investor",
  "DFI",
  "Development Organization",
  "Media",
  "Other",
];

const Field = ({ label, required, children, hint }: { label: string; required?: boolean; children: React.ReactNode; hint?: string }) => (
  <div className="space-y-2">
    <Label className="text-sm font-medium text-navy">
      {label} {required && <span className="text-gold">*</span>}
    </Label>
    {children}
    {hint && <p className="text-xs text-gray-medium">{hint}</p>}
  </div>
);

const SummitSignup = () => {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [f, setF] = useState<Record<string, any>>({ sectors: [] });
  const set = (k: string, v: any) => setF((p) => ({ ...p, [k]: v }));

  const toggleSector = (s: string) => {
    const cur: string[] = f.sectors ?? [];
    set("sectors", cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.fullName?.trim()) return toast({ title: "Full name is required", variant: "destructive" });
    if (!f.email?.trim() || !/^\S+@\S+\.\S+$/.test(f.email)) return toast({ title: "Please enter a valid email", variant: "destructive" });
    if (!f.phone?.trim() || f.phone.replace(/\D/g, "").length < 7) return toast({ title: "Please enter a valid phone number", variant: "destructive" });
    if (!f.country?.trim()) return toast({ title: "Country is required", variant: "destructive" });

    if (!f.organization?.trim()) return toast({ title: "Organization is required", variant: "destructive" });
    if (!f.attendeeType) return toast({ title: "Please select attendee type", variant: "destructive" });

    setSubmitting(true);
    try {
      await submitForm({
        form_type: "summit_attendee",
        full_name: f.fullName,
        email: f.email,
        organization: f.organization,
        topic: "AIMS Summit Attendance",
        message: f.objective ?? "",
        extra: {
          phone: f.phone ?? "",
          country: f.country,
          role: f.role ?? "",
          attendeeType: f.attendeeType,
          sectors: f.sectors ?? [],
          objective: f.objective ?? "",
          referral: f.referral ?? "",
        },
      });
      setDone(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      toast({ title: "Submission failed", description: "Please try again shortly.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-gray-light">
        <Nav />
        <section className="pt-32 pb-24">
          <div className="max-w-[720px] mx-auto px-6 text-center">
            <div className="mx-auto h-16 w-16 rounded-full bg-gold/15 text-gold flex items-center justify-center mb-8">
              <Check className="h-8 w-8" />
            </div>
            <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Summit</span>
            <h1 className="text-4xl md:text-5xl font-bold text-navy mt-4 mb-6 leading-[1.1]">
              You're on the list for the <span className="italic">AIMS Summit</span>.
            </h1>
            <p className="text-lg text-gray-medium leading-relaxed mb-10">
              Thank you for registering your interest. The AIMS team will be in touch with details about Addis Ababa, February 2027.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button variant="navyOutline" asChild><Link to="/">Return Home</Link></Button>
              <Button variant="gold" asChild><Link to="/register">Explore Pathways</Link></Button>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-light">
      <Nav />
      <section className="pt-28 pb-20">
        <div className="max-w-[820px] mx-auto px-6">
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 text-sm text-gray-medium hover:text-navy mb-6"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </button>

          <div className="bg-white rounded-2xl shadow-elegant border border-border overflow-hidden">
            <div className="p-8 md:p-10 border-b border-border">
              <div className="flex items-center gap-3 mb-3">
                <div className="h-px w-10 bg-gold" />
                <span className="text-xs uppercase tracking-[0.25em] font-semibold text-gold">AIMS Summit</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-navy leading-tight">Join the AIMS Summit</h1>
              <p className="text-gray-medium mt-3">
                A curated convening of governments, private sector, DFIs, and institutional investors.
              </p>
              <div className="flex flex-wrap gap-x-6 gap-y-2 mt-5 text-sm text-navy/80">
                <span className="inline-flex items-center gap-2"><MapPin className="h-4 w-4 text-gold" /> Addis Ababa</span>
                <span className="inline-flex items-center gap-2"><Calendar className="h-4 w-4 text-gold" /> February 2027</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-8 md:p-10 space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Field label="Full Name" required>
                  <Input value={f.fullName ?? ""} onChange={(e) => set("fullName", e.target.value)} placeholder="Jane Doe" maxLength={100} />
                </Field>
                <Field label="Email Address" required>
                  <Input type="email" value={f.email ?? ""} onChange={(e) => set("email", e.target.value)} placeholder="you@org.com" maxLength={255} />
                </Field>
                <Field label="Phone Number" required hint="Include country code">
                  <Input type="tel" value={f.phone ?? ""} onChange={(e) => set("phone", e.target.value)} placeholder="+254 700 000 000" maxLength={32} />

                </Field>
                <Field label="Country" required>
                  <Input value={f.country ?? ""} onChange={(e) => set("country", e.target.value)} maxLength={80} />
                </Field>
                <Field label="Organization" required>
                  <Input value={f.organization ?? ""} onChange={(e) => set("organization", e.target.value)} maxLength={140} />
                </Field>
                <Field label="Job Title / Role">
                  <Input value={f.role ?? ""} onChange={(e) => set("role", e.target.value)} maxLength={140} />
                </Field>
              </div>

              <Field label="Attendee Type" required>
                <Select value={f.attendeeType ?? ""} onValueChange={(v) => set("attendeeType", v)}>
                  <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                  <SelectContent>
                    {ATTENDEE_TYPES.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>

              <Field label="Sectors of Interest" hint="Select all that apply">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SECTORS.map((s) => {
                    const checked = (f.sectors ?? []).includes(s);
                    return (
                      <button
                        key={s}
                        type="button"
                        onClick={() => toggleSector(s)}
                        className={`text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
                          checked ? "border-gold bg-gold/10 text-navy font-semibold" : "border-border bg-white text-gray-medium hover:border-gold/50"
                        }`}
                      >
                        {s}
                      </button>
                    );
                  })}
                </div>
              </Field>

              <Field label="What do you hope to achieve at the Summit?">
                <Textarea value={f.objective ?? ""} onChange={(e) => set("objective", e.target.value)} rows={4} maxLength={1000} />
              </Field>

              <Field label="How did you hear about us? (optional)">
                <Input value={f.referral ?? ""} onChange={(e) => set("referral", e.target.value)} maxLength={140} />
              </Field>

              <div className="pt-4 flex items-center justify-between">
                <p className="text-xs text-gray-medium">Confidential, reviewed by the AIMS team.</p>
                <Button type="submit" variant="gold" size="lg" disabled={submitting}>
                  {submitting ? "Submitting…" : <>Register Interest <ArrowRight className="h-4 w-4" /></>}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default SummitSignup;