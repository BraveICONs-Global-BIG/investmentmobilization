import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Briefcase, Sparkles, TrendingUp, Globe2 } from "lucide-react";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { submitForm } from "@/lib/submitForm";

const SECTORS = ["Infrastructure", "Energy", "Housing", "Transport", "Agriculture", "Industrial Development", "Technology"];

const schema = z.object({
  full_name: z.string().trim().min(2, "Name is required").max(120),
  email: z.string().trim().email("Valid email required").max(255),
  phone: z.string().trim().min(7, "Valid phone number required").max(32),
  organization: z.string().trim().max(160).optional().or(z.literal("")),
  role: z.string().trim().max(120).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  participantType: z.string().max(80).optional().or(z.literal("")),
  sectors: z.array(z.string()).min(1, "Select at least one sector"),
  geographies: z.string().trim().max(200).optional().or(z.literal("")),
  ticketSize: z.string().max(40).optional().or(z.literal("")),
  capitalType: z.string().max(80).optional().or(z.literal("")),
  timeline: z.string().max(80).optional().or(z.literal("")),
  opportunityFocus: z.string().trim().max(800).optional().or(z.literal("")),
  message: z.string().trim().max(800).optional().or(z.literal("")),
});

const Opportunities = () => {
  const [submitting, setSubmitting] = useState(false);
  const [participantType, setParticipantType] = useState("");
  const [ticketSize, setTicketSize] = useState("");
  const [capitalType, setCapitalType] = useState("");
  const [timeline, setTimeline] = useState("");
  const [sectors, setSectors] = useState<string[]>([]);

  const toggleSector = (s: string) =>
    setSectors((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      full_name: String(fd.get("full_name") || ""),
      email: String(fd.get("email") || ""),
      phone: String(fd.get("phone") || ""),
      organization: String(fd.get("organization") || ""),
      role: String(fd.get("role") || ""),
      country: String(fd.get("country") || ""),
      participantType,
      sectors,
      geographies: String(fd.get("geographies") || ""),
      ticketSize,
      capitalType,
      timeline,
      opportunityFocus: String(fd.get("opportunityFocus") || ""),
      message: String(fd.get("message") || ""),
    };

    const parsed = schema.safeParse(payload);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }
    setSubmitting(true);
    try {
      await submitForm({ form_type: "register_opportunities", ...parsed.data });
      toast.success("Thank you, we'll be in touch with relevant opportunities.");
      (e.target as HTMLFormElement).reset();
      setParticipantType("");
      setTicketSize("");
      setCapitalType("");
      setTimeline("");
      setSectors([]);
    } catch (err) {
      toast.error("Could not submit. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-navy">
      <Nav />

      {/* Hero */}
      <section className="relative gradient-hero text-white pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-gold/20 blur-[120px]" />
          <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[hsl(var(--navy-light))] blur-[140px]" />
        </div>
        <div className="relative max-w-[1100px] mx-auto px-6 lg:px-10 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold/15 border border-gold/30 mb-8">
            <Sparkles className="h-3.5 w-3.5 text-gold" />
            <span className="text-gold text-[11px] uppercase tracking-[0.25em] font-semibold">Investment Pipeline</span>
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.02] mb-8">
            <span className="text-gold italic">Opportunities</span>
          </h1>
          <p className="text-lg md:text-xl text-white/75 leading-relaxed max-w-2xl mx-auto mb-10">
            Get early visibility into structured, investment-ready opportunities and
            emerging deals across the IMX ecosystem. Tell us what you're looking for and
            we'll match you to relevant pipeline.
          </p>
          <div className="flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-white/70">
            <span className="inline-flex items-center gap-2"><Briefcase className="h-4 w-4 text-gold" />Curated pipeline</span>
            <span className="inline-flex items-center gap-2"><TrendingUp className="h-4 w-4 text-gold" />Investment-ready</span>
            <span className="inline-flex items-center gap-2"><Globe2 className="h-4 w-4 text-gold" />Across emerging markets</span>
          </div>
        </div>
      </section>

      {/* Interest form */}
      <section id="register" className="py-24 md:py-32">
        <div className="max-w-[820px] mx-auto px-6 lg:px-10">
          <div className="mb-10 text-center">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="h-px w-10 bg-gold" />
              <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Register Interest</span>
              <div className="h-px w-10 bg-gold" />
            </div>
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
              Tell us what you're looking for
            </h2>
            <p className="text-gray-medium leading-relaxed max-w-xl mx-auto">
              Share your investment focus and we'll surface matching opportunities from
              the IMX pipeline as they're structured.
            </p>
          </div>

          <form onSubmit={onSubmit} className="bg-gray-light border border-border rounded-2xl p-6 sm:p-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <Label htmlFor="full_name">Full name *</Label>
              <Input id="full_name" name="full_name" required maxLength={120} />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input id="email" name="email" type="email" required maxLength={255} />
            </div>
            <div>
              <Label htmlFor="phone">Phone number *</Label>
              <Input id="phone" name="phone" type="tel" required maxLength={32} placeholder="+254 700 000 000" />
            </div>
            <div>
              <Label htmlFor="organization">Organization</Label>
              <Input id="organization" name="organization" maxLength={160} />
            </div>
            <div>
              <Label htmlFor="role">Role / Title</Label>
              <Input id="role" name="role" maxLength={120} />
            </div>
            <div>
              <Label htmlFor="country">Country</Label>
              <Input id="country" name="country" maxLength={80} />
            </div>
            <div>
              <Label>I am a…</Label>
              <Select value={participantType} onValueChange={setParticipantType}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Investor / Capital Provider">Investor / Capital Provider</SelectItem>
                  <SelectItem value="Private Sector Executive">Private Sector Executive</SelectItem>
                  <SelectItem value="Public Sector Executive">Public Sector Executive</SelectItem>
                  <SelectItem value="Development Partner">Development Partner</SelectItem>
                  <SelectItem value="Advisor / Intermediary">Advisor / Intermediary</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="sm:col-span-2">
              <Label>Sectors of interest *</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                {SECTORS.map((s) => {
                  const checked = sectors.includes(s);
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleSector(s)}
                      className={`text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
                        checked
                          ? "border-gold bg-gold/10 text-navy font-semibold"
                          : "border-border bg-background text-gray-medium hover:border-gold/50"
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="sm:col-span-2">
              <Label htmlFor="geographies">Geographies of interest</Label>
              <Input id="geographies" name="geographies" maxLength={200} placeholder="e.g. East Africa, Nigeria, SADC" />
            </div>

            <div>
              <Label>Typical ticket size</Label>
              <Select value={ticketSize} onValueChange={setTicketSize}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {["<$1M", "$1M–$10M", "$10M–$50M", "$50M–$200M", "$200M+"].map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Type of capital</Label>
              <Select value={capitalType} onValueChange={setCapitalType}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {["Equity", "Debt", "Blended", "Grant / Concessional", "Other"].map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="sm:col-span-2">
              <Label>Deployment timeline</Label>
              <Select value={timeline} onValueChange={setTimeline}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {["Immediate (0–3 months)", "Short-term (3–6 months)", "Medium-term (6–12 months)", "Exploratory"].map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="sm:col-span-2">
              <Label htmlFor="opportunityFocus">What type of opportunities are you seeking?</Label>
              <Textarea id="opportunityFocus" name="opportunityFocus" rows={4} maxLength={800}
                placeholder="Describe the kind of deals, structures, or sectors you want first access to." />
            </div>

            <div className="sm:col-span-2">
              <Label htmlFor="message">Anything else we should know? (optional)</Label>
              <Textarea id="message" name="message" rows={3} maxLength={800} />
            </div>

            <div className="sm:col-span-2 flex justify-end pt-2">
              <Button type="submit" variant="gold" size="lg" disabled={submitting}>
                {submitting ? "Submitting…" : "Register Interest"}
              </Button>
            </div>
          </form>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Opportunities;
