import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { GraduationCap, Sparkles, Clock, MapPin } from "lucide-react";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { submitForm } from "@/lib/submitForm";

const schema = z.object({
  full_name: z.string().trim().min(2, "Name is required").max(120),
  email: z.string().trim().email("Valid email required").max(255),
  phone: z.string().trim().min(7, "Valid phone number required").max(32),
  organization: z.string().trim().max(160).optional().or(z.literal("")),
  role: z.string().trim().max(120).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  participantType: z.string().max(80).optional().or(z.literal("")),
  onsiteDelivery: z.enum(["Yes", "No", "Maybe"], { errorMap: () => ({ message: "Please choose an option" }) }),
  facilityLocation: z.string().trim().max(200).optional().or(z.literal("")),
  groupSize: z.string().trim().max(40).optional().or(z.literal("")),
  message: z.string().trim().max(800).optional().or(z.literal("")),
});

const Institute = () => {
  const [submitting, setSubmitting] = useState(false);
  const [participantType, setParticipantType] = useState("");
  const [onsiteDelivery, setOnsiteDelivery] = useState<"Yes" | "No" | "Maybe" | "">("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      full_name: String(fd.get("full_name") || ""),
      email: String(fd.get("email") || ""),
      phone: String(fd.get("phone") || ""),
      organization: String(fd.get("organization") || ""),
      role: String(fd.get("role") || ""),
      country: String(fd.get("country") || ""),
      participantType,
      onsiteDelivery,
      facilityLocation: String(fd.get("facilityLocation") || ""),
      groupSize: String(fd.get("groupSize") || ""),
      message: String(fd.get("message") || ""),
    };

    const parsed = schema.safeParse(payload);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }
    setSubmitting(true);
    try {
      await submitForm({ form_type: "register_institute", ...parsed.data });
      toast.success("Thank you, we'll be in touch as The Institute opens.");
      (e.target as HTMLFormElement).reset();
      setParticipantType("");
      setOnsiteDelivery("");
    } catch (err) {
      toast.error("Could not submit. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-navy">
      <Nav />

      {/* Hero */}
      <section className="relative gradient-hero text-white pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-gold/20 blur-[120px]" />
          <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[hsl(var(--navy-light))] blur-[140px]" />
        </div>
        <div className="relative max-w-[1100px] mx-auto px-6 lg:px-10 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold/15 border border-gold/30 mb-8">
            <Sparkles className="h-3.5 w-3.5 text-gold" />
            <span className="text-gold text-[11px] uppercase tracking-[0.25em] font-semibold">Opening Soon</span>
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.02] mb-8">
            The <span className="text-gold italic">Institute</span>
          </h1>
          <p className="text-lg md:text-xl text-white/75 leading-relaxed max-w-2xl mx-auto mb-10">
            A dedicated learning and certification platform for investment mobilization,
            equipping leaders, teams, and institutions with the discipline of turning
            opportunities into bankable, deployable pipelines.
          </p>
          <div className="flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-white/70">
            <span className="inline-flex items-center gap-2"><GraduationCap className="h-4 w-4 text-gold" />Executive curriculum</span>
            <span className="inline-flex items-center gap-2"><Clock className="h-4 w-4 text-gold" />Launching Soon</span>
            <span className="inline-flex items-center gap-2"><MapPin className="h-4 w-4 text-gold" />Virtual & on-site</span>
          </div>
        </div>
      </section>

      {/* Interest form */}
      <section id="register" className="py-24 md:py-32">
        <div className="max-w-[820px] mx-auto px-6 lg:px-10">
          <div className="mb-10 text-center">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="h-px w-10 bg-gold" />
              <span className="text-gold text-xs uppercase tracking-[0.25em] font-semibold">Register Interest</span>
              <div className="h-px w-10 bg-gold" />
            </div>
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
              Be first in line when The Institute opens
            </h2>
            <p className="text-gray-medium leading-relaxed max-w-xl mx-auto">
              Tell us about you and your organization. We'll share program details, cohort
              dates, and on-site delivery options as they're confirmed.
            </p>
          </div>

          <form onSubmit={onSubmit} className="bg-gray-light border border-border rounded-2xl p-6 sm:p-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <Label htmlFor="full_name">Full name *</Label>
              <Input id="full_name" name="full_name" required maxLength={120} />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input id="email" name="email" type="email" required maxLength={255} />
            </div>
            <div>
              <Label htmlFor="phone">Phone number *</Label>
              <Input id="phone" name="phone" type="tel" required maxLength={32} placeholder="+254 700 000 000" />
            </div>
            <div>
              <Label htmlFor="organization">Organization</Label>
              <Input id="organization" name="organization" maxLength={160} />
            </div>
            <div>
              <Label htmlFor="role">Role / Title</Label>
              <Input id="role" name="role" maxLength={120} />
            </div>
            <div>
              <Label htmlFor="country">Country</Label>
              <Input id="country" name="country" maxLength={80} />
            </div>
            <div>
              <Label>I am a…</Label>
              <Select value={participantType} onValueChange={setParticipantType}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Public Sector Executive">Public Sector Executive</SelectItem>
                  <SelectItem value="Private Sector Executive">Private Sector Executive</SelectItem>
                  <SelectItem value="Investor / Capital Provider">Investor / Capital Provider</SelectItem>
                  <SelectItem value="Development Partner">Development Partner</SelectItem>
                  <SelectItem value="Academic / Institution">Academic / Institution</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="sm:col-span-2 mt-2 p-5 rounded-xl bg-background border border-border">
              <Label className="text-base font-semibold text-navy">
                Would you like us to come into your facility to deliver the session? *
              </Label>
              <p className="text-xs text-gray-medium mt-1 mb-3">
                We can deliver The Institute curriculum on-site for your team, ministry, or organization.
              </p>
              <RadioGroup
                value={onsiteDelivery}
                onValueChange={(v) => setOnsiteDelivery(v as "Yes" | "No" | "Maybe")}
                className="flex flex-wrap gap-4"
              >
                {(["Yes", "No", "Maybe"] as const).map((opt) => (
                  <div key={opt} className="flex items-center gap-2">
                    <RadioGroupItem id={`onsite-${opt}`} value={opt} />
                    <Label htmlFor={`onsite-${opt}`} className="font-normal cursor-pointer">{opt}</Label>
                  </div>
                ))}
              </RadioGroup>

              {(onsiteDelivery === "Yes" || onsiteDelivery === "Maybe") && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                  <div>
                    <Label htmlFor="facilityLocation">Facility location (city, country)</Label>
                    <Input id="facilityLocation" name="facilityLocation" maxLength={200} />
                  </div>
                  <div>
                    <Label htmlFor="groupSize">Approx. group size</Label>
                    <Input id="groupSize" name="groupSize" maxLength={40} placeholder="e.g. 25" />
                  </div>
                </div>
              )}
            </div>

            <div className="sm:col-span-2">
              <Label htmlFor="message">Anything we should know? (optional)</Label>
              <Textarea id="message" name="message" rows={4} maxLength={800} />
            </div>

            <div className="sm:col-span-2 flex justify-end pt-2">
              <Button type="submit" variant="gold" size="lg" disabled={submitting}>
                {submitting ? "Submitting…" : "Register Interest"}
              </Button>
            </div>
          </form>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Institute;
